<?php
defined('ABSPATH') || exit;
/**
 * Template Name: Category Detail Page
 */
?><!DOCTYPE html>
<html lang="he" dir="rtl" id="html-root">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>קטגוריה | טקס פרסי היכל התהילה של המוזיקה היהודית</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Heebo:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root {
  --gold: #D4AE54; --gold-light: #EDD06E; --gold-dark: #9A7A2A;
  --gold-glow: rgba(212,174,84,0.16);
  --blue: #2A4A7F; --blue-light: #3D6BAF; --blue-glow: rgba(42,74,127,0.25);
  --black: #0C0E14; --dark1: #12151E; --dark2: #1A1F2E; --dark3: #222840;
  --grey1: #1C1E24; --grey2: #252830; --grey3: #2E3240;
  --white: #F6F1E8; --white-70: rgba(246,241,232,0.72);
  --white-40: rgba(246,241,232,0.42); --white-12: rgba(246,241,232,0.13);
  --white-06: rgba(246,241,232,0.07);
}
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }

body {
  background: var(--black); color: var(--white);
  font-family: 'Heebo', sans-serif;
  direction: rtl; overflow-x: hidden; line-height: 1.6;
}
body.lang-en {
  direction: ltr;
  font-family: 'Cormorant Garamond', serif;
  font-size: 106%; letter-spacing: 0.01em;
}
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: var(--black); }
::-webkit-scrollbar-thumb { background: var(--gold-dark); }
a { text-decoration: none; color: inherit; }

.he { display: block; } .en { display: none; }
body.lang-en .he { display: none !important; }
body.lang-en .en { display: block !important; }
span.he, span.en { display: inline; }
body.lang-en span.he { display: none !important; }
body.lang-en span.en { display: inline !important; }

/* NAVBAR */
#navbar {
  position: fixed; inset: 0 0 auto; z-index: 900;
  display: flex; align-items: center; justify-content: space-between;
  padding: 1.1rem 2.5rem;
  background: rgba(12,14,20,0.97);
  border-bottom: 1px solid rgba(212,174,84,0.18);
  direction: ltr;
}
.nav-brand { display: flex; align-items: center; gap: 0.75rem; }
.nav-star {
  width: 38px; height: 38px; border: 1.5px solid var(--gold);
  border-radius: 50%; display: flex; align-items: center;
  justify-content: center; font-size: 1.1rem;
}
.nav-brand-text .t1 { font-size: 0.78rem; font-weight: 700; color: var(--gold); }
.nav-brand-text .t2 { font-size: 0.58rem; color: var(--white-40); letter-spacing: 2px; text-transform: uppercase; }
.nav-links { display: flex; gap: 2rem; list-style: none; }
.nav-links a { font-size: 0.72rem; letter-spacing: 1.5px; text-transform: uppercase; color: var(--white-70); transition: color 0.2s; }
.nav-links a:hover, .nav-links a.active { color: var(--gold); }
#lang-btn {
  background: transparent; border: 1px solid var(--gold); color: var(--gold);
  font-size: 0.7rem; letter-spacing: 2px; padding: 0.35rem 1rem;
  cursor: pointer; font-family: inherit; transition: all 0.2s;
}
#lang-btn:hover { background: var(--gold); color: var(--black); }

/* PAGE HERO */
.page-hero {
  padding: 9rem 2rem 5rem;
  text-align: center;
  background:
    radial-gradient(ellipse 80% 60% at 50% 70%, rgba(42,74,127,0.22), transparent 70%),
    radial-gradient(ellipse 80% 50% at 50% 60%, rgba(212,174,84,0.08), transparent 70%),
    linear-gradient(175deg, var(--dark1), var(--black));
  border-bottom: 1px solid rgba(212,174,84,0.12);
  position: relative;
}
.page-hero::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--gold), transparent);
}
.eyebrow {
  display: block; font-size: 0.65rem; letter-spacing: 5px;
  text-transform: uppercase; color: var(--gold); margin-bottom: 0.9rem;
  animation: labelGlow 3s ease-in-out infinite;
  text-shadow: 0 0 12px rgba(212,174,84,0.3);
}
.cat-icon-hero {
  font-size: 3.5rem; margin-bottom: 1rem;
  display: block;
  filter: drop-shadow(0 0 20px rgba(212,174,84,0.3));
}
.page-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(2.5rem, 6vw, 4.5rem);
  font-weight: 700; line-height: 1.1; margin-bottom: 0.5rem;
  text-shadow: 0 2px 20px rgba(42,74,127,0.15);
}
body:not(.lang-en) .page-title { font-family: 'Heebo', sans-serif; font-weight: 900; }
.cat-num-label {
  font-size: 0.65rem; letter-spacing: 4px; text-transform: uppercase;
  color: var(--white-40); margin-bottom: 0.4rem; display: block;
}
.rule {
  width: 60px; height: 2px; margin: 1.4rem auto;
  background: linear-gradient(90deg, transparent, var(--gold), var(--blue-light), var(--gold), transparent);
  background-size: 200% auto;
  animation: shimmer 3s linear infinite;
}
.page-intro {
  max-width: 640px; margin: 0 auto 2rem; color: var(--white-70);
  font-size: 1rem; line-height: 1.85;
}
.badge-row { display: flex; justify-content: center; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 1.5rem; }
.peoples-badge {
  background: var(--gold); color: var(--black);
  font-size: 0.62rem; font-weight: 700; letter-spacing: 2px;
  text-transform: uppercase; padding: 0.3rem 1rem;
}
.world-badge {
  background: transparent; color: var(--gold);
  border: 1px solid var(--gold);
  font-size: 0.62rem; letter-spacing: 2px;
  text-transform: uppercase; padding: 0.3rem 1rem;
}

/* BACK LINK */
.back-link-wrap { text-align: center; padding: 1.5rem 2rem 0; }
.back-link {
  font-size: 0.72rem; letter-spacing: 2px; text-transform: uppercase;
  color: var(--white-40); transition: color 0.2s;
  display: inline-flex; align-items: center; gap: 0.4rem;
}
.back-link:hover { color: var(--gold); }

/* NAV ARROWS */
.cat-nav {
  display: flex; justify-content: center; gap: 1rem;
  padding: 2rem 2rem 0; flex-wrap: wrap;
}
.cat-nav-btn {
  background: transparent; border: 1px solid var(--white-12);
  color: var(--white-40); font-size: 0.7rem; letter-spacing: 2px;
  text-transform: uppercase; padding: 0.5rem 1.4rem;
  cursor: pointer; font-family: inherit; transition: all 0.2s;
  display: flex; align-items: center; gap: 0.5rem;
}
.cat-nav-btn:hover { border-color: var(--gold); color: var(--gold); }

/* INDUCTEES */
#inductees {
  max-width: 1100px; margin: 0 auto;
  padding: 4rem 2rem 6rem;
}
.inductees-title {
  text-align: center; margin-bottom: 0.5rem;
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(1.5rem, 3vw, 2rem); font-weight: 600;
  color: var(--gold);
}
body:not(.lang-en) .inductees-title { font-family: 'Heebo', sans-serif; font-weight: 800; }
.inductees-sub {
  text-align: center; color: var(--white-40);
  font-size: 0.8rem; letter-spacing: 1px; margin-bottom: 3rem;
}
.inductees-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2px;
}

/* INDUCTEE CARD */
.ind-card {
  background: linear-gradient(135deg, var(--dark2), var(--grey2));
  padding: 0;
  display: flex; flex-direction: column;
  border-bottom: 2px solid transparent;
  opacity: 0; transform: translateY(28px);
  transition: opacity 0.7s, transform 0.7s, border-color 0.3s, box-shadow 0.3s;
}
.ind-card.on { opacity: 1; transform: translateY(0); }
.ind-card:hover {
  transform: translateY(-5px) !important;
  border-bottom-color: var(--gold);
  box-shadow: 0 12px 40px rgba(42,74,127,0.25), 0 4px 12px rgba(212,174,84,0.12);
}

.ind-avatar {
  height: 90px;
  background: linear-gradient(135deg, var(--dark3), var(--grey3));
  display: flex; align-items: center; justify-content: center;
  font-size: 2.2rem;
  border-bottom: 1px solid var(--white-06);
  position: relative; overflow: hidden;
}
.ind-avatar::before {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(135deg, rgba(212,174,84,0.08), transparent 60%);
  opacity: 0; transition: opacity 0.3s;
}
.ind-card:hover .ind-avatar::before { opacity: 1; }
.ind-initials {
  width: 60px; height: 60px; border-radius: 50%;
  background: linear-gradient(135deg, var(--blue), var(--dark3));
  border: 1.5px solid rgba(212,174,84,0.3);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.2rem; font-weight: 700; color: var(--gold);
  font-family: 'Cormorant Garamond', serif;
  letter-spacing: 1px;
}

.ind-body { padding: 1.8rem 1.8rem 1.4rem; flex: 1; }
.ind-years {
  font-size: 0.65rem; letter-spacing: 3px; color: var(--gold);
  margin-bottom: 0.5rem; direction: ltr; display: inline-block;
}
.ind-name {
  font-size: 1.4rem; font-weight: 700; line-height: 1.2; margin-bottom: 0.25rem;
}
body.lang-en .ind-name { font-family: 'Cormorant Garamond', serif; font-size: 1.6rem; font-weight: 600; }
.ind-tag {
  display: inline-block; font-size: 0.62rem; letter-spacing: 1.5px;
  text-transform: uppercase; color: var(--white-40);
  border: 1px solid var(--white-12); padding: 0.2rem 0.6rem;
  margin-bottom: 1.2rem;
}
.ind-bio {
  font-size: 0.88rem; color: var(--white-70); line-height: 1.8;
  margin-bottom: 1.2rem;
}

.ind-footer {
  padding: 1rem 1.8rem;
  border-top: 1px solid var(--white-06);
  display: flex; align-items: center; gap: 0.6rem;
}
.ind-work-label {
  font-size: 0.6rem; letter-spacing: 2px; text-transform: uppercase;
  color: var(--gold-dark);
}
.ind-work {
  font-size: 0.82rem; color: var(--white-70);
  font-style: italic;
}
body.lang-en .ind-work { font-family: 'Cormorant Garamond', serif; font-size: 1rem; }

/* VOTE SECTION */
#vote-section {
  background: linear-gradient(135deg, var(--grey2), var(--dark3));
  border-top: 1px solid rgba(212,174,84,0.15);
  border-bottom: 1px solid rgba(212,174,84,0.15);
  padding: 5rem 2rem;
  text-align: center;
  position: relative; overflow: hidden;
}
#vote-section::before {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse 60% 50% at 50% 50%, rgba(212,174,84,0.07), transparent 70%);
}
.vote-eyebrow { display: block; font-size: 0.65rem; letter-spacing: 5px; text-transform: uppercase; color: var(--gold); margin-bottom: 1rem; }
.vote-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(2rem, 4vw, 3rem); font-weight: 700; margin-bottom: 1rem;
  position: relative;
}
body:not(.lang-en) .vote-title { font-family: 'Heebo', sans-serif; font-weight: 900; }
.vote-sub { max-width: 540px; margin: 0 auto 2.5rem; color: var(--white-70); line-height: 1.8; position: relative; }
.vote-candidates { display: flex; flex-wrap: wrap; gap: 1rem; justify-content: center; margin-bottom: 2.5rem; position: relative; }
.vote-chip {
  background: var(--dark2); border: 1px solid var(--white-12);
  padding: 0.6rem 1.4rem; font-size: 0.82rem; cursor: pointer;
  transition: all 0.2s; font-family: inherit; color: var(--white-70);
  display: flex; align-items: center; gap: 0.5rem;
}
.vote-chip:hover, .vote-chip.selected {
  background: rgba(212,174,84,0.12); border-color: var(--gold); color: var(--gold);
}
.vote-chip .check { display: none; font-size: 0.75rem; }
.vote-chip.selected .check { display: inline; }
.btn-vote {
  display: inline-block; padding: 1rem 3rem;
  background: var(--gold); color: var(--black);
  font-size: 0.8rem; letter-spacing: 3px; text-transform: uppercase;
  font-weight: 700; font-family: inherit; cursor: pointer;
  border: none; transition: all 0.22s; position: relative;
}
.btn-vote:hover { background: var(--gold-light); transform: translateY(-2px); box-shadow: 0 10px 30px rgba(212,174,84,0.25); }
.vote-note { margin-top: 1.2rem; font-size: 0.72rem; color: var(--white-40); letter-spacing: 0.5px; position: relative; }
.vote-thanks { display: none; font-size: 1.1rem; color: var(--gold); padding: 1.5rem; }

/* FOOTER */
footer {
  background: linear-gradient(180deg, var(--dark1), var(--black));
  border-top: 1px solid var(--white-06);
  padding: 2.5rem 2rem;
  text-align: center;
}
.footer-links { display: flex; gap: 2rem; justify-content: center; flex-wrap: wrap; margin-bottom: 1.2rem; }
.footer-links a { font-size: 0.75rem; color: var(--white-40); letter-spacing: 1px; transition: color 0.2s; }
.footer-links a:hover { color: var(--gold); }
.footer-copy { font-size: 0.7rem; color: var(--white-40); }

@keyframes shimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
@keyframes labelGlow { 0%, 100% { opacity: 0.85; letter-spacing: 5px; } 50% { opacity: 1; letter-spacing: 5.5px; } }

@media (max-width: 900px) { .nav-links { display: none; } }
@media (max-width: 600px) {
  #navbar { padding: 1rem 1.2rem; }
  .inductees-grid { grid-template-columns: 1fr; }
  #inductees { padding: 3rem 1rem 4rem; }
}
</style>
</head>
<body <?php body_class(); ?>>

<!-- NAVBAR -->
<nav id="navbar">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-brand">
    <div class="nav-star">✡</div>
    <div class="nav-brand-text">
      <div class="t1 he">טקס פרסי היכל התהילה</div>
      <div class="t1 en">Hall of Fame Awards</div>
      <div class="t2">Jewish Music · 2027</div>
    </div>
  </a>
  <ul class="nav-links">
    <li><a href="<?php echo esc_url(home_url('/')); ?>"><span class="he">בית</span><span class="en">Home</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/categories/')); ?>" class="active"><span class="he">קטגוריות</span><span class="en">Categories</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/support/')); ?>"><span class="he">תורמים</span><span class="en">Support Us</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/#ceremony')); ?>"><span class="he">הטקס</span><span class="en">Ceremony</span></a></li>
  </ul>
  <button id="lang-btn" onclick="switchLang()">ENGLISH</button>
</nav>

<!-- PAGE HERO — rendered by JS -->
<div id="page-hero" class="page-hero">
  <span class="eyebrow"><span class="he">מחזור 2027 · היכל התהילה</span><span class="en">Inaugural Class 2027 · Hall of Fame</span></span>
  <span id="hero-icon" class="cat-icon-hero"></span>
  <span id="hero-cat-num" class="cat-num-label"></span>
  <h1 class="page-title" id="hero-title">…</h1>
  <div class="rule"></div>
  <p class="page-intro" id="hero-desc">…</p>
  <div class="badge-row" id="hero-badges"></div>
</div>

<!-- BACK + NAV -->
<div class="back-link-wrap">
  <a href="<?php echo esc_url(home_url('/categories/')); ?>" class="back-link">
    <span class="he">← כל הקטגוריות</span>
    <span class="en">← All Categories</span>
  </a>
</div>
<div class="cat-nav" id="cat-nav"></div>

<!-- INDUCTEES -->
<section id="inductees">
  <div class="inductees-title">
    <span class="he">אגדות שייכנסו להיכל התהילה</span>
    <span class="en">Legends Entering the Hall of Fame</span>
  </div>
  <p class="inductees-sub">
    <span class="he">אמנים שהלכו לעולמם ותרומתם לא תישכח — המועמדים לקבל את פרס ההיכל בקטגוריה זו</span>
    <span class="en">Artists who are no longer with us yet whose contribution will never be forgotten — nominees to receive the Hall of Fame award in this category</span>
  </p>
  <div class="inductees-grid" id="inductees-grid"></div>
</section>

<!-- VOTE SECTION (cat 12 only) -->
<section id="vote-section" style="display:none;">
  <span class="vote-eyebrow"><span class="he">פרס הקהל · 2027</span><span class="en">People's Choice Award · 2027</span></span>
  <h2 class="vote-title">
    <span class="he">הצביעו עכשיו</span>
    <span class="en">Cast Your Vote</span>
  </h2>
  <p class="vote-sub">
    <span class="he">זוהי הקטגוריה היחידה שבה הקהל הוא השופט. בחרו את נגן כלי ההקשה היהודי שלדעתכם הותיר את החותם הגדול ביותר.</span>
    <span class="en">This is the only category where the public is the judge. Choose the Jewish percussionist who you believe left the greatest mark.</span>
  </p>
  <div class="vote-candidates" id="vote-candidates"></div>
  <div id="vote-action">
    <button class="btn-vote" onclick="submitVote()">
      <span class="he">שלחו את הצבעתכם</span>
      <span class="en">Submit My Vote</span>
    </button>
    <p class="vote-note">
      <span class="he">הצבעה אחת למשתמש · ההצבעה נסגרת ב-1 בדצמבר 2027</span>
      <span class="en">One vote per user · Voting closes December 1, 2027</span>
    </p>
  </div>
  <div class="vote-thanks" id="vote-thanks">
    <span class="he">✓ תודה על הצבעתכם! קולכם נספר.</span>
    <span class="en">✓ Thank you for your vote! Your voice is counted.</span>
  </div>
</section>

<hr style="max-width:1100px;margin:0 auto;border:none;border-top:1px solid var(--white-06);">

<!-- FOOTER -->
<footer>
  <div class="footer-links">
    <a href="<?php echo esc_url(home_url('/')); ?>"><span class="he">דף הבית</span><span class="en">Home</span></a>
    <a href="<?php echo esc_url(home_url('/categories/')); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a>
    <a href="<?php echo esc_url(home_url('/support/')); ?>"><span class="he">תמיכה</span><span class="en">Support Us</span></a>
    <a href="<?php echo esc_url(home_url('/#process')); ?>"><span class="he">תהליך הבחירה</span><span class="en">Selection</span></a>
  </div>
  <div class="footer-copy">
    © 2026 ✡ <span class="he">טקס פרסי היכל התהילה של המוזיקה היהודית</span><span class="en">Jewish Music Hall of Fame Awards</span>
  </div>
</footer>

<script>
/* ── BASE URLS (WP) ── */
const BASE_URL = '<?php echo esc_js(home_url('/category/?catid=')); ?>';
const CATS_URL = '<?php echo esc_js(home_url('/categories/')); ?>';

/* ── CATEGORIES DATA ── */
const CATEGORIES = {
  '01': {
    icon: '🎤', nameHe: 'זמר', nameEn: 'Male Singer',
    subHe: 'בכל השפות והסגנונות', subEn: 'All languages & styles',
    badge: null,
    descHe: 'זמר יהודי שהותיר חותם בלתי נמחה על המוזיקה היהודית — בכל שפה ובכל סגנון. מיידיש וספרדית ועד ערבית ועברית, ממוזיקה דתית ועד מוזיקת עולם.',
    descEn: 'A Jewish male vocalist who has left an indelible mark on Jewish music — in any language and any style. From Yiddish and Ladino to Arabic and Hebrew, from sacred music to world music.',
    inductees: [
      { initials:'AJ', nameHe:"אל ג'ולסון", nameEn:'Al Jolson', years:'1886 – 1950',
        tagHe:'מוזיקה אמריקאית · יידיש', tagEn:'American Pop · Yiddish',
        bioHe:'נולד בליטא בשם אסא יואלסון, עלה לאמריקה בילדותו ונעשה לכוכב הבידור הגדול ביותר של תחילת המאה ה-20. קולו הדרמטי ונוכחותו על הבמה שינו את פני הבידור האמריקאי לנצח.',
        bioEn:'Born Asa Yoelson in Lithuania, he immigrated to America as a child and became the greatest entertainment star of the early 20th century. His dramatic voice and stage presence changed American entertainment forever.',
        workHe:'"My Yiddishe Mama" · "Mammy" (1927)', workEn:'"My Yiddishe Mama" · "Mammy" (1927)' },
      { initials:'JP', nameHe:'יאן פירס', nameEn:'Jan Peerce', years:'1904 – 1984',
        tagHe:'אופרה · מוזיקה יהודית', tagEn:'Opera · Jewish Music',
        bioHe:'טנור אמריקאי מוביל שניהל קריירה מקבילה — עשורים רבים ב-Metropolitan Opera לצד הופעות בבתי כנסת ובמוזיקה יהודית. גישר בין האמנות הגבוהה לבין המסורת בצורה שאיש לא עשה לפניו.',
        bioEn:'A leading American tenor who sustained a parallel career — decades at the Metropolitan Opera alongside synagogue performances and Jewish recordings. He bridged high art and tradition like no one before him.',
        workHe:'"Bluebird of Happiness" · ביצועי חזנות ב-Met', workEn:'"Bluebird of Happiness" · Cantorial performances at the Met' },
      { initials:'TB', nameHe:'תאודור ביקל', nameEn:'Theodore Bikel', years:'1924 – 2015',
        tagHe:"פולקלור יהודי · יידיש · פעילות", tagEn:'Jewish Folklore · Yiddish · Activism',
        bioHe:"שחקן, זמר ופעיל שנולד בווינה ועלה לישראל לפני שהפך לכוכב בינלאומי. הקליט עשרות אלבומים בשפות ובסגנונות יהודיים שונים, ושימר את הפולקלור היהודי לדורות.",
        bioEn:"Actor, singer and activist born in Vienna who moved to Israel before becoming an international star. He recorded dozens of albums in various Jewish languages and styles, preserving Jewish folklore for generations.",
        workHe:'אלבום "Jewish Folk Songs" (1955) · "Fiddler on the Roof"', workEn:'Album "Jewish Folk Songs" (1955) · "Fiddler on the Roof"' }
    ]
  },
  '02': {
    icon:'🎤', nameHe:'זמרת', nameEn:'Female Singer',
    subHe:'בכל השפות והסגנונות', subEn:'All languages & styles', badge:null,
    descHe:'זמרת יהודייה שקולה ואמנותה עיצבו את הזהות המוזיקלית היהודית לדורות. הקטגוריה פתוחה לכל שפה, תקופה וסגנון.',
    descEn:'A Jewish female vocalist whose voice and artistry have shaped Jewish musical identity for generations. Open to any language, era, and style.',
    inductees:[
      { initials:'MP', nameHe:'מולי פיקון', nameEn:'Molly Picon', years:'1898 – 1992',
        tagHe:'תיאטרון יידיש · קומדיה', tagEn:'Yiddish Theatre · Comedy',
        bioHe:'מלכת תיאטרון היידיש בניו יורק ובוורשה. כוכבת שהצחיקה ושיגעה קהלים ביידיש, אנגלית ועברית במשך יותר משבעה עשורים. קולה וחיוכה הפכו לסמל של יהדות אמריקה.',
        bioEn:'Queen of Yiddish theatre in New York and Warsaw. A star who thrilled audiences in Yiddish, English and Hebrew for over seven decades. Her voice and smile became a symbol of American Jewry.',
        workHe:'פיל"מ "Yidl mitn Fidl" (1936) · הופעות ברחבי העולם', workEn:'Film "Yidl mitn Fidl" (1936) · Worldwide performances' },
      { initials:'ST', nameHe:'סופי טאקר', nameEn:'Sophie Tucker', years:'1886 – 1966',
        tagHe:'קברט אמריקאי · יידיש', tagEn:'American Cabaret · Yiddish',
        bioHe:'כונתה "The Last of the Red Hot Mammas" — אחד מגדולי כוכבי הבידור האמריקאי. שרה ביידיש ובאנגלית, שברה מוסכמות ופרצה דרך לנשים יהודיות בתעשיית הבידור.',
        bioEn:'Known as "The Last of the Red Hot Mammas" — one of the greatest stars of American entertainment. She sang in Yiddish and English, broke conventions, and paved the way for Jewish women in the entertainment industry.',
        workHe:'"My Yiddishe Mama" · 60 שנות קריירה', workEn:'"My Yiddishe Mama" · 60 years of performing' },
      { initials:'שד', nameHe:'שושנה דמארי', nameEn:'Shoshana Damari', years:'1923 – 2006',
        tagHe:'זמר עברי · תימן', tagEn:'Hebrew Song · Yemenite',
        bioHe:'נולדה בתימן ועלתה לארץ ישראל בילדותה. קולה הייחודי והחם, שמזג שורשים תימניים עם הזמר העברי המתהווה, הפך אותה לסמל תרבותי של מדינת ישראל הצעירה.',
        bioEn:'Born in Yemen and immigrated to Mandatory Palestine as a child. Her distinctive, warm voice — blending Yemenite roots with emerging Hebrew song — made her a cultural symbol of the young State of Israel.',
        workHe:'"כלניות" · "אחוה" · הופעות בניצחון 1948', workEn:'"Kalaniyot" · "Ahava" · Performances at the 1948 independence' }
    ]
  },
  '03': {
    icon:'🕍', nameHe:'חזן / פייטן', nameEn:'Cantor / Paytan',
    subHe:'אשכנזי ומזרחי', subEn:'Ashkenazi & Mizrahi', badge:null,
    descHe:'חזן או פייטן שיצירתו מגשרת בין הקודש לאמנות — בין אם בנוסח האשכנזי, הספרדי, התימני או המזרחי.',
    descEn:'A cantor or paytan whose work bridges the sacred and the artistic — whether in Ashkenazi, Sephardic, Yemenite or Mizrahi tradition.',
    inductees:[
      { initials:'יר', nameHe:"יוסל'ה רוזנבלט", nameEn:'Yossele Rosenblatt', years:'1882 – 1933',
        tagHe:'חזנות אשכנזית', tagEn:'Ashkenazi Cantorial',
        bioHe:'נחשב לגדול החזנים של המאה ה-20. קולו האדיר — שילוב נדיר של קאונטר-טנור וטנור — ריסק לבבות בהיכלות ובבתי כנסת מניו יורק ועד ירושלים.',
        bioEn:"Considered the greatest cantor of the 20th century. His immense voice — a rare blend of counter-tenor and tenor — broke hearts in concert halls and synagogues from New York to Jerusalem.",
        workHe:'"Kol Nidre" · "Eli Eli" · הקלטות Columbia Records', workEn:'"Kol Nidre" · "Eli Eli" · Columbia Records recordings' },
      { initials:'RT', nameHe:"ריצ'רד טאקר", nameEn:'Richard Tucker', years:'1913 – 1975',
        tagHe:'אופרה · חזנות', tagEn:'Opera · Cantorial',
        bioHe:"טנור אופראי אמריקאי מוביל שניצח על הבמות הגדולות בעולם, ובמקביל המשיך לשיר חזנות בבית הכנסת.",
        bioEn:"A leading American operatic tenor who performed on the world's greatest stages while continuing to sing as a cantor in synagogue.",
        workHe:'הופעות ב-Metropolitan Opera · הקלטות חזנות', workEn:'Metropolitan Opera performances · Cantorial recordings' },
      { initials:'מכ', nameHe:'משה קוסביצקי', nameEn:'Moshe Koussevitzky', years:'1899 – 1966',
        tagHe:'חזנות פולנית', tagEn:'Polish Cantorial Tradition',
        bioHe:'החזן הגדול של וורשה, שקולו המרשים וסגנון פרשנותו הייחודי הפכו אותו לאגדה עוד בחייו. ניצל את השואה ועלה לאמריקה.',
        bioEn:'The great cantor of Warsaw, whose impressive voice and unique interpretive style made him a legend in his own lifetime. He survived the Holocaust and immigrated to America.',
        workHe:'הקלטות יידיש · ביצועי "אבינו מלכנו"', workEn:'Yiddish recordings · Performances of "Avinu Malkeinu"' }
    ]
  },
  '04': {
    icon:'🇮🇱', nameHe:'זמר ישראלי', nameEn:'Israeli Male Singer',
    subHe:"זמר עברי, פופ, רוק, ג'אז", subEn:'Hebrew song, pop, rock, jazz', badge:null,
    descHe:'זמר ישראלי שתרם תרומה יוצאת דופן לזמר העברי ולתרבות הישראלית.',
    descEn:'An Israeli male singer who made an outstanding contribution to Hebrew song and Israeli culture.',
    inductees:[
      { initials:'אא', nameHe:'אריק אינשטיין', nameEn:'Arik Einstein', years:'1939 – 2013',
        tagHe:"רוק ישראלי · פופ · ז'אנר מגדיר", tagEn:'Israeli Rock · Pop · Genre-Defining',
        bioHe:'נחשב על ידי רבים לזמר הישראלי הגדול מכולם. יותר מחמישה עשורים של יצירה שינו את פני המוזיקה הישראלית.',
        bioEn:'Widely considered the greatest Israeli singer of all time. More than five decades of work transformed Israeli music.',
        workHe:'"לו יהי" · "שיר בוקר" · "אני ואתה"', workEn:'"Lu Yehi" · "Shir Boker" · "Ani Ve\'Ata"' },
      { initials:'יב', nameHe:'יוסי בנאי', nameEn:'Yossi Banai', years:'1932 – 2006',
        tagHe:"שנסון · זמר עברי · תיאטרון", tagEn:'Chanson · Hebrew Song · Theatre',
        bioHe:"שחקן, זמר וקומיקאי שהפך לאייקון תרבותי ישראלי. שייגרם לצרפתי עם נשמה ישראלית — שיריו תמיד נגעו עמוק.",
        bioEn:'Actor, singer and comedian who became an Israeli cultural icon. French chanson with an Israeli soul — his songs always touched deeply.',
        workHe:'"שרלוט" · "הייתי רוצה" · "הדלת הנעולה"', workEn:'"Charlotte" · "Hayiti Rotze" · "Ha\'Delet HaNe\'ula"' },
      { initials:'זא', nameHe:'זוהר ארגוב', nameEn:'Zohar Argov', years:'1955 – 1987',
        tagHe:'מוזיקה מזרחית · "המלך"', tagEn:'Mizrahi Music · "The King"',
        bioHe:'כינויו "המלך" — ובצדק. בחיים קצרים ורוויי סערות, הפך קולו לאנתם של יהדות המזרח בישראל.',
        bioEn:'Nicknamed "The King" — and rightfully so. In a brief and tumultuous life, his voice became the anthem of Mizrahi Jewry in Israel.',
        workHe:'"עלי עין" · "הפרח בגני" · "אהבה גדולה"', workEn:'"Elie Elie" · "HaPerach BeGani" · "Ahava Gdola"' }
    ]
  },
  '05': {
    icon:'🇮🇱', nameHe:'זמרת ישראלית', nameEn:'Israeli Female Singer',
    subHe:"זמר עברי, פופ, רוק, ג'אז", subEn:'Hebrew song, pop, rock, jazz', badge:null,
    descHe:"זמרת ישראלית שקולה הפך לסמל תרבותי — בזמר עברי, פופ, רוק או ג'אז.",
    descEn:'An Israeli female singer whose voice became a cultural symbol — in Hebrew song, pop, rock or jazz.',
    inductees:[
      { initials:'אח', nameHe:'אופרה חזה', nameEn:'Ofra Haza', years:'1957 – 2000',
        tagHe:'פופ ישראלי · תימני · עולמי', tagEn:'Israeli Pop · Yemenite · Global',
        bioHe:'כוכבת ישראלית שכבשה את העולם. שיריה שמזגו עוצמה תימנית עם ביט מודרני הפכו לאנתמים בינלאומיים. נפטרה בגיל 42 — אגדה בלתי גמורה.',
        bioEn:'An Israeli star who conquered the world. Her songs blending Yemenite power with a modern beat became international anthems. She died at 42 — an unfinished legend.',
        workHe:'"Im Nin\'alu" · "Galbi" · "Shir HaShirim"', workEn:'"Im Nin\'alu" · "Galbi" · "Shir HaShirim"' },
      { initials:'בצ', nameHe:'ברכה צפירה', nameEn:'Bracha Zefira', years:'1910 – 1990',
        tagHe:'פולקלור יהודי · ריבוי-תרבויות', tagEn:'Jewish Folklore · Multicultural',
        bioHe:'חלוצה של המוזיקה הישראלית שהביאה את שירי הגלויות — מתימן, מרוקו, פרס, ספרד — לבמה הישראלית.',
        bioEn:'A pioneer of Israeli music who brought the songs of the diaspora — from Yemen, Morocco, Persia, Spain — to the Israeli stage.',
        workHe:'אלבומי שירי גלויות · הופעות בפסטיבלים בינלאומיים', workEn:'Diaspora song albums · International festival performances' },
      { initials:'נה', nameHe:'נחמה הנדל', nameEn:'Nehama Hendel', years:'1934 – 2012',
        tagHe:'זמר עברי · ארץ ישראלי', tagEn:'Hebrew Folk Song · Israeli',
        bioHe:'קולה החם והאמין של הזמר הארץ-ישראלי. שיריה ליוו דורות של ישראלים בשמחות ובעצבות.',
        bioEn:'The warm, authentic voice of the Israeli folk song tradition. Her songs accompanied generations of Israelis through celebrations and sorrows.',
        workHe:'"אם יש את נפשך" · "שיר המעלות" · הופעות על פני 5 עשורים', workEn:'"Im Yesh Et Nafshecha" · Performances across 5 decades' }
    ]
  },
  '06': {
    icon:'🌊', nameHe:'זמר/ת ים-תיכוני', nameEn:'Mediterranean Singer',
    subHe:'מישראל ומארצות המזרח', subEn:'From Israel & Eastern countries', badge:null,
    descHe:'אמן/ית שמוזיקתם שואבת ממסורות ים-תיכוניות ומזרחיות — ממרוקו, תוניסיה, לוב, מצרים, תורכיה, פרס וכן ישראל.',
    descEn:'An artist whose music draws from Mediterranean and Eastern traditions — from Morocco, Tunisia, Libya, Egypt, Turkey, Persia and Israel.',
    inductees:[
      { initials:'זא', nameHe:'זוהר ארגוב', nameEn:'Zohar Argov', years:'1955 – 1987',
        tagHe:'מוזיקה מזרחית ישראלית', tagEn:'Israeli Mizrahi Music',
        bioHe:'"המלך" של המוזיקה הים-תיכונית הישראלית. שיריו הציפו את צלילי המזרח לחדרי המגורים של כל ישראל.',
        bioEn:'"The King" of Israeli Mediterranean music. His songs flooded Israeli living rooms with the sounds of the East.',
        workHe:'"עלי עין" · "הפרח בגני"', workEn:'"Elie Elie" · "HaPerach BeGani"' },
      { initials:'SH', nameHe:'סלים חלאלי', nameEn:'Salim Halali', years:'1920 – 2005',
        tagHe:"קברט פריזאי · אלג'יריה-מרוקו", tagEn:'Parisian Cabaret · Algerian-Moroccan',
        bioHe:"יהודי ממוצא אלג'יראי-מרוקאי שכבש את בתי הקברט של פריז בשנות ה-30 וה-40. ניצל את השואה בזכות מקלט שמצא במסגד פריז.",
        bioEn:'A Jewish singer of Algerian-Moroccan origin who conquered the cabarets of Paris in the 1930s and 40s. He survived the Holocaust by finding refuge in the Paris Mosque.',
        workHe:'הקלטות קברט פריזאיות · 1935–1950', workEn:'Parisian cabaret recordings · 1935–1950' },
      { initials:'JA', nameHe:"ג'ו עמר", nameEn:'Jo Amar', years:'1930 – 2008',
        tagHe:'מרוקאי-ישראלי · פייטנות', tagEn:'Moroccan-Israeli · Piyyut',
        bioHe:'נולד במכנס שבמרוקו ועלה לישראל, שם הפך לאחד הקולות הגדולים ביותר של המוזיקה היהודית-מרוקאית.',
        bioEn:'Born in Meknès, Morocco, and immigrated to Israel, where he became one of the greatest voices of Moroccan Jewish music.',
        workHe:'"דידי" · פיוטים ושירי שבת', workEn:'"Didi" · Piyyutim and Shabbat songs' }
    ]
  },
  '07': {
    icon:'🎸', nameHe:'להקה / הרכב', nameEn:'Band / Ensemble',
    subHe:"כל הסגנונות והשפות, כליזמר", subEn:'All styles & languages, klezmer', badge:null,
    descHe:"להקה או הרכב יהודי — ממצמד ומעלה — שיצירתם המשותפת העשירה את עולם המוזיקה היהודית.",
    descEn:"A Jewish band or ensemble — duos and above — whose collaborative work has enriched the world of Jewish music.",
    inductees:[
      { initials:'BS', nameHe:'אחיות בארי', nameEn:'The Barry Sisters', years:'1940s – 1997',
        tagHe:'יידיש אמריקאי · מצמד', tagEn:'American Yiddish · Duo',
        bioHe:'קלרה ומרנה בגלמן — "אחיות בארי" — היו מלכות המוזיקה היידישית האמריקאית. שיריהן הגיעו לאוזניים ב-30 מדינות.',
        bioEn:'Clara and Merna Bagelman — The Barry Sisters — were the queens of American Yiddish music. Their songs reached ears in 30 countries.',
        workHe:'"Roumania" · "Bei Mir Bist Du Sheyn" · עשרות אלבומים', workEn:'"Roumania" · "Bei Mir Bist Du Sheyn" · Dozens of albums' },
      { initials:'גח', nameHe:'הגשש החיוור', nameEn:'HaGashash HaHiver', years:'1963 – 2006',
        tagHe:'קומדיה ישראלית · שירה', tagEn:'Israeli Comedy · Song',
        bioHe:"השלישיה האגדית — שייקה לוי, גברי בנאי, ישראל פוליאקוב — שהיתה הרבה יותר מקומיקאים. שיריהם ומערכוניהם עיצבו את ה'ישראליות' לדורות.",
        bioEn:"The legendary trio — Shaike Levi, Gavri Banai, Yisrael Poliakov — who were far more than comedians. Their songs and sketches defined Israeli identity for generations.",
        workHe:'"פחד" · "מותק" · מופעים שסיכמו תקופה', workEn:'"Pachad" · "Motek" · Performances that defined an era' },
      { initials:'DT', nameHe:"דייב טאראס ועמיתיו", nameEn:"Dave Tarras & Associates", years:'1897 – 1989',
        tagHe:'כליזמר · קלרינט', tagEn:'Klezmer · Clarinet',
        bioHe:'דייב טאראס, הקלרינטיסט הגדול של עולם הכליזמר, הוביל הרכבים שהגדירו את הצליל היהודי-אמריקאי.',
        bioEn:'Dave Tarras, the great clarinetist of the klezmer world, led ensembles that defined the Jewish-American sound.',
        workHe:'הקלטות Decca Records · "Freilachs" · מורשת הכליזמר', workEn:'Decca Records recordings · "Freilachs" · Klezmer heritage' }
    ]
  },
  '08': {
    icon:'🎼', nameHe:'מלחין / מעבד / מנצח', nameEn:'Composer / Arranger / Conductor',
    subHe:'קלאסי, מחזמר, אופרה', subEn:'Classical, musical theatre, opera', badge:null,
    descHe:'יוצר שמאחורי הקלעים — מלחין, מעבד או מנצח — שיצירותיו הפכו לאבני יסוד של הרפרטואר המוזיקלי היהודי.',
    descEn:'A behind-the-scenes creator — composer, arranger or conductor — whose works became cornerstones of the Jewish musical repertoire.',
    inductees:[
      { initials:'LB', nameHe:'לאונרד ברנשטיין', nameEn:'Leonard Bernstein', years:'1918 – 1990',
        tagHe:'קלאסי · מחזמר · מנצח', tagEn:'Classical · Musical Theatre · Conductor',
        bioHe:'אחד המוזיקאים הגדולים של המאה ה-20. מנצח, מלחין ופדגוג שיצר את "West Side Story" ו"מיסה", ניצח על ה-New York Philharmonic.',
        bioEn:'One of the greatest musicians of the 20th century. Conductor, composer and educator who created "West Side Story" and "Mass" and conducted the New York Philharmonic.',
        workHe:'"West Side Story" · "Chichester Psalms" · "Candide"', workEn:'"West Side Story" · "Chichester Psalms" · "Candide"' },
      { initials:'GG', nameHe:"ג'ורג' גרשווין", nameEn:'George Gershwin', years:'1898 – 1937',
        tagHe:"ג'אז · קלאסי · מחזמר", tagEn:'Jazz · Classical · Musical Theatre',
        bioHe:'גאון מוזיקלי שנפטר בגיל 38 — ועזב מאחוריו קנון שמשפיע על מוזיקאים עד היום.',
        bioEn:'A musical genius who died at 38 — leaving behind a canon that influences musicians to this day.',
        workHe:'"Rhapsody in Blue" · "Porgy and Bess" · "Someone to Watch Over Me"', workEn:'"Rhapsody in Blue" · "Porgy and Bess" · "Someone to Watch Over Me"' },
      { initials:'נש', nameHe:'נעמי שמר', nameEn:'Naomi Shemer', years:'1930 – 2004',
        tagHe:'זמר עברי · ישראל · מלחינה', tagEn:'Hebrew Song · Israel · Composer',
        bioHe:'"ירושלים של זהב" נכתב שלושה שבועות לפני מלחמת ששת הימים והפך לשיר הלאומי הבלתי רשמי של ישראל.',
        bioEn:'"Jerusalem of Gold" was written three weeks before the Six-Day War and became Israel\'s unofficial national anthem.',
        workHe:'"ירושלים של זהב" · "לו יהי" · "אל תיקחי ממני את השמש"', workEn:'"Jerusalem of Gold" · "Lu Yehi" · "Al Tiqchi Mimeni et HaShemesh"' }
    ]
  },
  '09': {
    icon:'🎹', nameHe:'פסנתרן', nameEn:'Pianist',
    subHe:'קלאסי ופופולרי', subEn:'Classical & popular', badge:'trustees',
    descHe:"פסנתרן/ית יהודי/ה שהשאיר/ה חותם בינלאומי על עולם הפסנתר — בתחום הקלאסי, הג'אז, הפופ או הפופולרי. פרס זה מוענק כפרס חבר הנאמנים העולמי.",
    descEn:'A Jewish pianist who has left an international mark on the world of piano — classical, jazz, pop or popular. This award is designated the World Trustees Award.',
    inductees:[
      { initials:'AR', nameHe:'ארתור רובינשטיין', nameEn:'Arthur Rubinstein', years:'1887 – 1982',
        tagHe:'פסנתר קלאסי · בינלאומי', tagEn:'Classical Piano · International',
        bioHe:"אחד הפסנתרנים הגדולים בתולדות המוזיקה. נולד בלודז' שבפולין וכבש את במות העולם במשך 8 עשורים.",
        bioEn:'One of the greatest pianists in music history. Born in Łódź, Poland, he conquered the world\'s stages for 8 decades.',
        workHe:'פרשנויות שופן · ברהמס · הופעות בקרנגי הול', workEn:'Chopin & Brahms interpretations · Carnegie Hall performances' },
      { initials:'VH', nameHe:'ולדימיר הורוביץ', nameEn:'Vladimir Horowitz', years:'1903 – 1989',
        tagHe:'פסנתר קלאסי · וירטואוז', tagEn:'Classical Piano · Virtuoso',
        bioHe:'וירטואוז הפסנתר המיתולוגי. נולד בקייב. חזרתו לבמה ב-1965 אחרי 12 שנות פרישה היתה אחד הרגעים הגדולים בתולדות המוזיקה.',
        bioEn:'The mythological piano virtuoso. Born in Kyiv. His return to the stage in 1965 after 12 years of retirement was one of the greatest moments in music history.',
        workHe:'חזרה ל-Carnegie Hall (1965) · הקלטות Columbia Masterworks', workEn:'Return to Carnegie Hall (1965) · Columbia Masterworks recordings' },
      { initials:'CH', nameHe:'קלרה האסקיל', nameEn:'Clara Haskil', years:'1895 – 1960',
        tagHe:'פסנתר קלאסי · מוצרט', tagEn:'Classical Piano · Mozart',
        bioHe:'פסנתרנית יהודייה-רומנית שפרשנותה למוצרט ולסקרלטי הפכה לאמת מידה מוחלטת.',
        bioEn:'A Romanian-Jewish pianist whose interpretations of Mozart and Scarlatti became the absolute benchmark.',
        workHe:'פרשנויות מוצרט · הקלטות פיליפס', workEn:'Mozart interpretations · Philips recordings' }
    ]
  },
  '10': {
    icon:'🎻', nameHe:'נגן כלי מיתר', nameEn:'String Instrumentalist',
    subHe:'קלאסי ופופולרי', subEn:'Classical & popular', badge:null,
    descHe:"נגן/ת כלי מיתר — כינור, ויולה, צ'לו, גיטרה, עוד וכדומה — שיצירותיו ופרשנויותיו חצו גבולות ועיצבו את פני המוזיקה היהודית.",
    descEn:'A string instrument player — violin, viola, cello, guitar, oud and more — whose works and interpretations crossed borders and shaped the face of Jewish music.',
    inductees:[
      { initials:'JH', nameHe:'יאשה היפץ', nameEn:'Jascha Heifetz', years:'1901 – 1987',
        tagHe:'כינור קלאסי · גדול הדורות', tagEn:'Classical Violin · Greatest of All Time',
        bioHe:'כינויו "גדול הכנרים בכל הדורות". נולד בווילנה ועלה לאמריקה בגיל 16.',
        bioEn:'Known as "the greatest violinist of all time." Born in Vilnius and immigrated to America at 16.',
        workHe:"קונצ'רטו לכינור של מנדלסון · ברמס · שיאצ'ופסקי", workEn:'Mendelssohn Violin Concerto · Brahms · Tchaikovsky' },
      { initials:'YM', nameHe:'יהודי מנוהין', nameEn:'Yehudi Menuhin', years:'1916 – 1999',
        tagHe:'כינור קלאסי · שגריר עולמי', tagEn:'Classical Violin · World Ambassador',
        bioHe:'כנר בוגא ואנושי שניצח על ליבות הקהלים ביותר מ-50 מדינות. ייסד פסטיבל מוזיקה ובית ספר שנושאים את שמו עד היום.',
        bioEn:'A prodigiously talented violinist who captured audiences in more than 50 countries. He founded a music festival and school that bear his name to this day.',
        workHe:"קונצ'רטו של אלגר · אלתורים עם ראבי שאנקר", workEn:'Elgar Concerto · Improvisations with Ravi Shankar' },
      { initials:'NM', nameHe:'נתן מילשטיין', nameEn:'Nathan Milstein', years:'1904 – 1992',
        tagHe:'כינור קלאסי · רוסי-אמריקאי', tagEn:'Classical Violin · Russian-American',
        bioHe:'אחד הכנרים הגדולים של המאה ה-20. נולד באודסה, למד בסנט פטרסבורג, ועלה לאמריקה ב-1929.',
        bioEn:'One of the great violinists of the 20th century. Born in Odessa, trained in St. Petersburg, and immigrated to America in 1929.',
        workHe:"Partitas לבאך · קונצ'רטו של מנדלסון", workEn:'Bach Partitas · Mendelssohn Concerto' }
    ]
  },
  '11': {
    icon:'🎷', nameHe:'נגן כלי נשיפה', nameEn:'Wind Instrumentalist',
    subHe:'קלאסי ופופולרי', subEn:'Classical & popular', badge:null,
    descHe:"נגן/ת כלי נשיפה — קלרינט, סקסופון, חליל, חצוצרה וכדומה — שמוזיקתם הגדירה את הצליל היהודי בכליזמר, בג'אז, בקלאסי או בפופולרי.",
    descEn:'A wind instrument player — clarinet, saxophone, flute, trumpet and more — whose music defined the Jewish sound, whether in klezmer, jazz, classical or popular genres.',
    inductees:[
      { initials:'BG', nameHe:'בני גודמן', nameEn:'Benny Goodman', years:'1909 – 1986',
        tagHe:'"מלך הסווינג" · קלרינט', tagEn:'"King of Swing" · Clarinet',
        bioHe:'כונה "מלך הסווינג" — ובצדק. בנג\'מין דייוויד גודמן הפך את הקלרינט לאייקון של עידן הג\'אז. הופעתו ב-Carnegie Hall ב-1938 נחשבת לאחת הגדולות.',
        bioEn:'Known as the "King of Swing." Benjamin David Goodman turned the clarinet into an icon of the Jazz Age. His 1938 Carnegie Hall concert is considered one of the greatest in jazz history.',
        workHe:'"Sing, Sing, Sing" · הופעת Carnegie Hall (1938)', workEn:'"Sing, Sing, Sing" · Carnegie Hall Concert (1938)' },
      { initials:'AS', nameHe:'ארטי שאו', nameEn:'Artie Shaw', years:'1910 – 2004',
        tagHe:"ג'אז · קלרינט · סווינג", tagEn:'Jazz · Clarinet · Swing',
        bioHe:"אחד הקלרינטיסטים הגדולים בתולדות הג'אז. \"Begin the Beguine\" (1938) היה מהאלפי הרוקדים הראשונים בהיסטוריה.",
        bioEn:'One of the greatest clarinetists in jazz history. "Begin the Beguine" (1938) was among the first platinum-selling records in history.',
        workHe:'"Begin the Beguine" · "Stardust" · ביג בנד', workEn:'"Begin the Beguine" · "Stardust" · Big Band' },
      { initials:'SG', nameHe:'סטן גץ', nameEn:'Stan Getz', years:'1927 – 1991',
        tagHe:"ג'אז · סקסופון · בוסה נובה", tagEn:'Jazz · Saxophone · Bossa Nova',
        bioHe:'כונה "The Sound" בשל צלילו הלירי והייחודי. "The Girl from Ipanema" הפכה לשיר הג\'אז המוכר ביותר בעולם.',
        bioEn:'Called "The Sound" for his lyrical, unique saxophone tone. "The Girl from Ipanema" became the most recognized jazz song in the world.',
        workHe:'"The Girl from Ipanema" · "Desafinado" · Jazz Samba', workEn:'"The Girl from Ipanema" · "Desafinado" · Jazz Samba' }
    ]
  },
  '12': {
    icon:'🥁', nameHe:'נגן כלי הקשה', nameEn:'Percussion Instrumentalist',
    subHe:"מישראל ומהתפוצות · פרס הקהל", subEn:"From Israel & diaspora · People's Choice", badge:'peoples',
    descHe:'נגן/ת כלי הקשה שמוזיקתם מגיעה מישראל ומהתפוצות — תופים, דרבוקה, מרקסים ועוד. הקטגוריה הזאת נבחרת על ידי הקהל הרחב — הצביעו!',
    descEn:'A percussion player from Israel or the diaspora — drums, darbuka, maracas and more. This category is chosen by the public — cast your vote!',
    inductees:[
      { initials:'BR', nameHe:"בדי ריץ'", nameEn:'Buddy Rich', years:'1917 – 1987',
        tagHe:"ג'אז · תופים · ניו יורק", tagEn:'Jazz · Drums · New York',
        bioHe:'נחשב רבות לתופף הגדול ביותר שחי. נולד בברוקלין להורים יהודים, התחיל לנגן בגיל שנתיים ולא עצר.',
        bioEn:'Widely considered the greatest drummer who ever lived. Born in Brooklyn to Jewish parents, he started playing at age two and never stopped.',
        workHe:'"West Side Story Medley" · הופעות ביג בנד · 60 שנות קריירה', workEn:'"West Side Story Medley" · Big Band performances · 60-year career' },
      { initials:'SM', nameHe:'שלי מאן', nameEn:'Shelly Manne', years:'1920 – 1984',
        tagHe:"ג'אז מודרני · תופים · LA", tagEn:'Modern Jazz · Drums · LA',
        bioHe:"אחד המתופפים המשפיעים ביותר בג'אז המודרני. שיתוף פעולתו עם אנדרה פרוין הפך אותו לאחד המתופפים הנשמעים ביותר.",
        bioEn:'One of the most influential drummers in modern jazz. His collaborations with André Previn made him one of the most recorded drummers in West Coast jazz history.',
        workHe:'"My Fair Lady" Jazz · Shelly Manne & His Men', workEn:'"My Fair Lady" Jazz · Shelly Manne & His Men' },
      { initials:'GF', nameHe:"ג'ורג' פאמה", nameEn:'George Fama', years:'1920 – 1998',
        tagHe:'דרבוקה · מוזיקה ים-תיכונית', tagEn:'Darbuka · Mediterranean Music',
        bioHe:'אחד הנגנים הגדולים של הדרבוקה בעולם היהודי-ערבי. מוזיקתו הפכה אותו לגשר בין תרבויות.',
        bioEn:'One of the great darbuka players in the Jewish-Arabic world. His music made him a bridge between cultures.',
        workHe:'מקאמות ים-תיכוניים · הקלטות אתנומוזיקה', workEn:'Mediterranean maqam · Ethnomusicological recordings' }
    ],
    voteOptions:[
      { nameHe:"בדי ריץ'", nameEn:'Buddy Rich' },
      { nameHe:'שלי מאן', nameEn:'Shelly Manne' },
      { nameHe:"ג'ורג' פאמה", nameEn:'George Fama' },
      { nameHe:'נגן אחר מהתפוצות', nameEn:'Other diaspora percussionist' }
    ]
  }
};

/* ── LANGUAGE ── */
let lang = 'he';
function switchLang() {
  lang = lang === 'he' ? 'en' : 'he';
  const body = document.body;
  const html = document.getElementById('html-root');
  const btn  = document.getElementById('lang-btn');
  if (lang === 'en') {
    body.classList.add('lang-en'); html.lang = 'en'; html.dir = 'ltr';
    btn.textContent = 'עברית';
    localStorage.setItem('lang', 'en');
  } else {
    body.classList.remove('lang-en'); html.lang = 'he'; html.dir = 'rtl';
    btn.textContent = 'ENGLISH';
    localStorage.setItem('lang', 'he');
  }
}

/* ── RENDER ── */
function getCatParam() {
  const p = new URLSearchParams(window.location.search).get('catid');
  return (p && CATEGORIES[p]) ? p : '01';
}

function renderPage() {
  const id  = getCatParam();
  const cat = CATEGORIES[id];
  const ids = Object.keys(CATEGORIES);
  const idx = ids.indexOf(id);

  document.title = cat.nameHe + ' / ' + cat.nameEn + ' | היכל התהילה של המוזיקה היהודית';

  document.getElementById('hero-icon').textContent = cat.icon;
  document.getElementById('hero-cat-num').textContent = 'קטגוריה ' + id + ' · CATEGORY ' + id;
  document.getElementById('hero-title').innerHTML =
    '<span class="he">' + cat.nameHe + '</span><span class="en">' + cat.nameEn + '</span>';
  document.getElementById('hero-desc').innerHTML =
    '<span class="he">' + cat.descHe + '</span><span class="en">' + cat.descEn + '</span>';

  const badgeRow = document.getElementById('hero-badges');
  badgeRow.innerHTML = '';
  if (cat.badge === 'peoples') {
    badgeRow.innerHTML = '<span class="peoples-badge he">פרס הקהל — הצביעו</span><span class="peoples-badge en">People\'s Choice — Vote Now</span>';
  } else if (cat.badge === 'trustees') {
    badgeRow.innerHTML = '<span class="world-badge he">פרס חבר הנאמנים העולמי</span><span class="world-badge en">World Trustees Award</span>';
  }

  const nav = document.getElementById('cat-nav');
  const prevId = ids[idx - 1];
  const nextId = ids[idx + 1];
  nav.innerHTML = '';
  if (prevId) {
    nav.innerHTML += '<button class="cat-nav-btn" onclick="location.href=\'' + BASE_URL + prevId + '\'">'
      + '← <span class="he">' + CATEGORIES[prevId].nameHe + '</span><span class="en">' + CATEGORIES[prevId].nameEn + '</span>'
      + '</button>';
  }
  if (nextId) {
    nav.innerHTML += '<button class="cat-nav-btn" onclick="location.href=\'' + BASE_URL + nextId + '\'">'
      + '<span class="he">' + CATEGORIES[nextId].nameHe + '</span><span class="en">' + CATEGORIES[nextId].nameEn + '</span> →'
      + '</button>';
  }

  const grid = document.getElementById('inductees-grid');
  grid.innerHTML = cat.inductees.map(function(ind, i) {
    return '<div class="ind-card" style="transition-delay:' + (i * 0.12) + 's">'
      + '<div class="ind-avatar"><div class="ind-initials">' + ind.initials + '</div></div>'
      + '<div class="ind-body">'
      + '<span class="ind-years" dir="ltr">' + ind.years + '</span>'
      + '<div class="ind-name"><span class="he">' + ind.nameHe + '</span><span class="en">' + ind.nameEn + '</span></div>'
      + '<span class="ind-tag"><span class="he">' + ind.tagHe + '</span><span class="en">' + ind.tagEn + '</span></span>'
      + '<p class="ind-bio"><span class="he">' + ind.bioHe + '</span><span class="en">' + ind.bioEn + '</span></p>'
      + '</div>'
      + '<div class="ind-footer">'
      + '<span class="ind-work-label he">יצירת מפתח:</span><span class="ind-work-label en">Key work:</span>'
      + '<span class="ind-work"><span class="he">' + ind.workHe + '</span><span class="en">' + ind.workEn + '</span></span>'
      + '</div></div>';
  }).join('');

  if (cat.badge === 'peoples' && cat.voteOptions) {
    document.getElementById('vote-section').style.display = 'block';
    const vc = document.getElementById('vote-candidates');
    vc.innerHTML = cat.voteOptions.map(function(opt, i) {
      return '<button class="vote-chip" onclick="selectVote(this,' + i + ')">'
        + '<span class="check">✓</span>'
        + '<span class="he">' + opt.nameHe + '</span><span class="en">' + opt.nameEn + '</span>'
        + '</button>';
    }).join('');
  }

  setTimeout(function() {
    const io = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) { if (e.isIntersecting) e.target.classList.add('on'); });
    }, { threshold: 0.12 });
    document.querySelectorAll('.ind-card').forEach(function(el) { io.observe(el); });
  }, 100);
}

/* ── VOTE ── */
let selectedVote = null;
function selectVote(el, idx) {
  document.querySelectorAll('.vote-chip').forEach(function(c) { c.classList.remove('selected'); });
  el.classList.add('selected');
  selectedVote = idx;
}
function submitVote() {
  if (selectedVote === null) {
    alert(lang === 'he' ? 'אנא בחרו מועמד לפני שליחת ההצבעה' : 'Please select a candidate before submitting.');
    return;
  }
  if (localStorage.getItem('voted-cat12')) {
    alert(lang === 'he' ? 'כבר הצבעתם! תודה.' : 'You already voted! Thank you.');
    return;
  }
  localStorage.setItem('voted-cat12', '1');
  document.getElementById('vote-action').style.display = 'none';
  document.getElementById('vote-thanks').style.display = 'block';
}

/* ── INIT ── */
const savedLang = localStorage.getItem('lang');
if (savedLang === 'en') {
  lang = 'en';
  document.body.classList.add('lang-en');
  document.getElementById('html-root').lang = 'en';
  document.getElementById('html-root').dir = 'ltr';
  document.getElementById('lang-btn').textContent = 'עברית';
}

renderPage();
</script>
<?php wp_footer(); ?>
</body>
</html>
