<?php
defined('ABSPATH') || exit;
/**
 * Template Name: Support Page
 */
$form_status = isset($_GET['form']) ? sanitize_key($_GET['form']) : '';
?><!DOCTYPE html>
<html lang="he" dir="rtl" id="html-root">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>שותפים לחזון | טקס פרסי היכל התהילה של המוזיקה היהודית</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Heebo:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root {
  --gold: #D4AE54; --gold-light: #EDD06E; --gold-dark: #9A7A2A;
  --gold-glow: rgba(212,174,84,0.16);
  --blue: #2A4A7F; --blue-light: #3D6BAF; --blue-glow: rgba(42,74,127,0.25);
  --black: #0C0E14; --dark1: #12151E; --dark2: #1A1F2E; --dark3: #222840;
  --grey1: #1C1E24; --grey2: #252830; --grey3: #2E3240;
  --white: #F6F1E8; --white-70: rgba(246,241,232,0.72);
  --white-40: rgba(246,241,232,0.42); --white-12: rgba(246,241,232,0.13);
  --white-06: rgba(246,241,232,0.07);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body {
  background: var(--black); color: var(--white);
  font-family: 'Heebo', sans-serif;
  direction: rtl; overflow-x: hidden;
}
body.lang-en { direction: ltr; font-family: 'Cormorant Garamond', serif; font-size: 106%; }

a { text-decoration: none; color: inherit; }
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: var(--black); }
::-webkit-scrollbar-thumb { background: var(--gold-dark); }

.he { display: block; } .en { display: none; }
body.lang-en .he { display: none !important; }
body.lang-en .en { display: block !important; }

@keyframes fadeUp   { from { opacity:0; transform:translateY(32px); } to { opacity:1; transform:none; } }
@keyframes shimmer  { 0% { background-position:-200% center; } 100% { background-position:200% center; } }
@keyframes pulseGold { 0%,100% { opacity:0.7; } 50% { opacity:1; } }

.reveal { opacity:0; transform:translateY(32px); transition:opacity 0.8s ease, transform 0.8s ease; }
.reveal.on { opacity:1; transform:none; }
.reveal-d1 { transition-delay:0.1s; }
.reveal-d2 { transition-delay:0.2s; }
.reveal-d3 { transition-delay:0.3s; }

/* NAVBAR */
#navbar {
  position: fixed; inset: 0 0 auto; z-index: 900; direction: ltr;
  display: flex; align-items: center; justify-content: space-between;
  padding: 1.1rem 2.5rem;
  background: rgba(12,14,20,0.97);
  border-bottom: 1px solid rgba(212,174,84,0.18);
  backdrop-filter: blur(8px);
}
.nav-brand { display: flex; align-items: center; gap: 0.75rem; }
.nav-star { width: 38px; height: 38px; border: 1.5px solid var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; transition: box-shadow 0.3s; }
.nav-star:hover { box-shadow: 0 0 16px rgba(42,74,127,0.5); }
.nav-brand-text .t1 { font-size: 0.78rem; font-weight: 700; color: var(--gold); }
.nav-brand-text .t2 { font-size: 0.58rem; color: var(--white-40); letter-spacing: 2px; text-transform: uppercase; }
.nav-links { display: flex; gap: 2rem; list-style: none; }
.nav-links a { font-size: 0.72rem; letter-spacing: 1.5px; text-transform: uppercase; color: var(--white-70); transition: color 0.2s; }
.nav-links a:hover, .nav-links a.active { color: var(--gold); }
#lang-btn { background: transparent; border: 1px solid var(--gold); color: var(--gold); font-size: 0.7rem; letter-spacing: 2px; padding: 0.35rem 1rem; cursor: pointer; font-family: inherit; transition: all 0.2s; }
#lang-btn:hover { background: var(--gold); color: var(--black); }

/* HERO */
.donor-hero {
  min-height: 100vh;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  text-align: center;
  padding: 9rem 2rem 5rem;
  position: relative; overflow: hidden;
  background:
    radial-gradient(ellipse 80% 60% at 50% 60%, rgba(42,74,127,0.22), transparent 65%),
    radial-gradient(ellipse 60% 40% at 50% 40%, rgba(212,174,84,0.08), transparent 60%),
    linear-gradient(175deg, var(--dark1) 0%, var(--black) 100%);
}
.donor-hero::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--gold), var(--blue-light), var(--gold), transparent);
  background-size: 200% auto;
  animation: shimmer 4s linear infinite;
}
.orb { position: absolute; border-radius: 50%; filter: blur(80px); pointer-events: none; opacity: 0.15; }
.orb-1 { width: 400px; height: 400px; background: var(--blue); top: 10%; right: -10%; }
.orb-2 { width: 300px; height: 300px; background: var(--gold-dark); bottom: 15%; left: -8%; }
.orb-3 { width: 250px; height: 250px; background: var(--blue-light); top: 50%; left: 50%; transform: translate(-50%,-50%); opacity: 0.08; }

.hero-eyebrow {
  display: inline-block;
  font-size: 0.65rem; letter-spacing: 5px; text-transform: uppercase;
  color: var(--gold); border: 1px solid rgba(212,174,84,0.3);
  padding: 0.35rem 1.4rem; margin-bottom: 2rem;
  animation: pulseGold 3s ease-in-out infinite;
}
.hero-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(2.8rem, 6vw, 5.5rem);
  font-weight: 700; line-height: 1.1; margin-bottom: 1.5rem;
  animation: fadeUp 1s 0.1s ease both;
  text-shadow: 0 4px 30px rgba(42,74,127,0.2);
}
body:not(.lang-en) .hero-title { font-family: 'Heebo', sans-serif; font-weight: 900; }
.hero-title .gold { color: var(--gold); }
.hero-quote {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(1.1rem, 2.5vw, 1.6rem); font-style: italic;
  color: var(--white-70); max-width: 700px; margin: 0 auto 2.5rem; line-height: 1.75;
  animation: fadeUp 1s 0.25s ease both;
}
body:not(.lang-en) .hero-quote { font-family: 'Heebo', sans-serif; font-style: normal; font-weight: 300; }
.hero-cta-group { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; animation: fadeUp 1s 0.4s ease both; }
.btn-gold {
  display: inline-block; padding: 0.9rem 2.5rem;
  background: var(--gold); color: var(--black);
  font-size: 0.78rem; font-weight: 700; letter-spacing: 2.5px;
  text-transform: uppercase; font-family: inherit; cursor: pointer;
  border: none; transition: all 0.25s;
}
.btn-gold:hover { background: var(--gold-light); transform: translateY(-2px); box-shadow: 0 10px 30px rgba(212,174,84,0.3); }
.btn-outline {
  display: inline-block; padding: 0.9rem 2.5rem;
  background: transparent; color: var(--white-70);
  border: 1px solid var(--white-40);
  font-size: 0.78rem; letter-spacing: 2.5px;
  text-transform: uppercase; font-family: inherit; cursor: pointer;
  transition: all 0.25s;
}
.btn-outline:hover { border-color: var(--gold); color: var(--gold); }
.hero-scroll-hint {
  position: absolute; bottom: 2rem; left: 50%; transform: translateX(-50%);
  font-size: 0.6rem; letter-spacing: 3px; text-transform: uppercase;
  color: var(--white-40); display: flex; flex-direction: column; align-items: center; gap: 0.5rem;
  animation: fadeUp 1s 0.8s ease both;
}
.scroll-arrow { font-size: 1.2rem; animation: pulseGold 2s ease-in-out infinite; color: var(--gold); }

/* WHY NOW */
.why-now {
  background: linear-gradient(135deg, var(--dark2), var(--grey2));
  padding: 5rem 2rem;
  border-top: 1px solid rgba(42,74,127,0.2);
  border-bottom: 1px solid rgba(42,74,127,0.2);
}
.why-now-inner { max-width: 900px; margin: 0 auto; text-align: center; }
.section-label {
  display: block; font-size: 0.65rem; letter-spacing: 5px;
  text-transform: uppercase; color: var(--gold); margin-bottom: 1rem;
  animation: pulseGold 3s ease-in-out infinite;
  text-shadow: 0 0 12px rgba(212,174,84,0.3);
}
.section-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(2rem, 4vw, 3rem); font-weight: 700; line-height: 1.2; margin-bottom: 1.5rem;
}
body:not(.lang-en) .section-title { font-family: 'Heebo', sans-serif; font-weight: 800; }
.rule {
  width: 48px; height: 2px; margin: 0 auto 2rem;
  background: linear-gradient(90deg, transparent, var(--gold), var(--blue-light), var(--gold), transparent);
  background-size: 200% auto; animation: shimmer 3s linear infinite;
}
.why-now-text { font-size: 1.05rem; color: var(--white-70); line-height: 1.9; max-width: 740px; margin: 0 auto 3rem; }
.why-pillars { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px; margin-top: 1rem; }
.pillar {
  background: linear-gradient(135deg, var(--dark1), var(--grey2));
  padding: 2rem 1.5rem; text-align: center;
  border-top: 2px solid transparent;
  transition: border-color 0.3s, transform 0.3s, box-shadow 0.3s;
}
.pillar:hover { border-top-color: var(--gold); transform: translateY(-5px); box-shadow: 0 12px 32px rgba(42,74,127,0.22); }
.pillar-icon { font-size: 2rem; margin-bottom: 0.8rem; }
.pillar-title { font-size: 0.9rem; font-weight: 700; color: var(--gold); margin-bottom: 0.6rem; }
body.lang-en .pillar-title { font-family: 'Cormorant Garamond', serif; font-size: 1.1rem; }
.pillar-text { font-size: 0.82rem; color: var(--white-70); line-height: 1.7; }

/* IMPACT */
.impact-section { background: linear-gradient(160deg, var(--dark1), var(--dark3)); padding: 6rem 2rem; }
.impact-inner { max-width: 1100px; margin: 0 auto; }
.impact-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px; margin-top: 3rem; }
.impact-box {
  background: linear-gradient(135deg, var(--dark2), var(--grey2));
  padding: 2.5rem 1.5rem; text-align: center;
  border-bottom: 2px solid transparent;
  transition: border-color 0.3s, transform 0.3s;
  position: relative; overflow: hidden;
}
.impact-box::before {
  content: ''; position: absolute; inset: 0;
  background: linear-gradient(135deg, var(--blue-glow), transparent 70%);
  opacity: 0; transition: opacity 0.3s;
}
.impact-box:hover { border-bottom-color: var(--gold); transform: translateY(-4px); }
.impact-box:hover::before { opacity: 1; }
.impact-num {
  font-family: 'Cormorant Garamond', serif;
  font-size: 3.5rem; font-weight: 700; color: var(--gold);
  line-height: 1; text-shadow: 0 0 30px rgba(212,174,84,0.35);
}
.impact-label { font-size: 0.78rem; color: var(--white-70); margin-top: 0.6rem; line-height: 1.5; }

/* TIERS */
.tiers-section { background: var(--black); padding: 6rem 2rem; }
.tiers-header { max-width: 900px; margin: 0 auto 4rem; text-align: center; }
.tiers-grid { max-width: 1100px; margin: 0 auto; display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px; }
.tier-card {
  background: linear-gradient(135deg, var(--dark2), var(--grey2));
  padding: 2.8rem 2rem;
  border-top: 3px solid var(--grey3);
  position: relative; overflow: hidden;
  transition: transform 0.3s, box-shadow 0.3s;
  display: flex; flex-direction: column;
}
.tier-card:hover { transform: translateY(-6px); box-shadow: 0 16px 48px rgba(42,74,127,0.28), 0 4px 16px rgba(212,174,84,0.1); }
.tier-card.featured { border-top-color: var(--gold); background: linear-gradient(135deg, var(--grey2), var(--dark3)); box-shadow: 0 0 0 1px rgba(212,174,84,0.2); }
.tier-card.featured::before { content: ''; position: absolute; inset: 0; background: linear-gradient(135deg, rgba(212,174,84,0.05), transparent 60%); }
.tier-top-badge {
  position: absolute; top: 0; left: 50%; transform: translateX(-50%);
  background: var(--gold); color: var(--black);
  font-size: 0.58rem; font-weight: 700; letter-spacing: 2px;
  text-transform: uppercase; padding: 0.25rem 1rem; white-space: nowrap;
}
.tier-level { font-size: 0.6rem; letter-spacing: 4px; text-transform: uppercase; color: var(--gold); margin-bottom: 0.6rem; margin-top: 0.5rem; }
.tier-name { font-size: 1.5rem; font-weight: 700; margin-bottom: 0.5rem; }
body.lang-en .tier-name { font-family: 'Cormorant Garamond', serif; font-size: 1.9rem; font-weight: 600; }
.tier-price { font-family: 'Cormorant Garamond', serif; font-size: 3rem; font-weight: 700; color: var(--gold); line-height: 1; }
.tier-price-note { font-size: 0.7rem; color: var(--white-40); margin-bottom: 1.5rem; margin-top: 0.2rem; }
.tier-impact {
  background: rgba(42,74,127,0.15);
  border-right: 3px solid var(--blue-light);
  padding: 0.8rem 1rem;
  font-size: 0.82rem; color: var(--white-70);
  line-height: 1.6; margin-bottom: 1.5rem; font-style: italic;
}
body.lang-en .tier-impact { border-right: none; border-left: 3px solid var(--blue-light); }
.tier-benefits { list-style: none; margin-bottom: 2rem; flex: 1; }
.tier-benefits li {
  font-size: 0.83rem; color: var(--white-70);
  padding: 0.55rem 0; border-bottom: 1px solid var(--white-06);
  display: flex; align-items: flex-start; gap: 0.7rem; line-height: 1.5;
}
.tier-benefits li .check { color: var(--gold); font-size: 0.65rem; margin-top: 0.3rem; flex-shrink: 0; }
.tier-cta {
  display: block; width: 100%; text-align: center;
  padding: 0.9rem; font-size: 0.75rem; font-weight: 700;
  letter-spacing: 2px; text-transform: uppercase;
  cursor: pointer; font-family: inherit; transition: all 0.25s;
  border: none; margin-top: auto;
}
.tier-card:not(.featured) .tier-cta { background: transparent; border: 1px solid var(--gold); color: var(--gold); }
.tier-card:not(.featured) .tier-cta:hover { background: var(--gold); color: var(--black); }
.tier-card.featured .tier-cta { background: var(--gold); color: var(--black); }
.tier-card.featured .tier-cta:hover { background: var(--gold-light); transform: translateY(-1px); }

/* VISION QUOTE */
.vision-quote-section {
  background: linear-gradient(135deg, var(--dark3), var(--grey2), var(--dark2));
  padding: 6rem 2rem; text-align: center;
  border-top: 1px solid rgba(42,74,127,0.2);
  border-bottom: 1px solid rgba(42,74,127,0.2);
  position: relative; overflow: hidden;
}
.vision-quote-section::before {
  content: '❝';
  position: absolute; top: 2rem; left: 50%; transform: translateX(-50%);
  font-size: 8rem; color: rgba(212,174,84,0.06);
  font-family: 'Cormorant Garamond', serif; line-height: 1;
}
.big-quote {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(1.4rem, 3vw, 2.2rem);
  font-weight: 400; font-style: italic;
  color: var(--white);
  max-width: 800px; margin: 0 auto 1.5rem;
  line-height: 1.6; position: relative; z-index: 1;
}
body:not(.lang-en) .big-quote { font-family: 'Heebo', sans-serif; font-style: normal; font-weight: 300; font-size: clamp(1.2rem, 2.5vw, 1.9rem); }
.quote-attr { font-size: 0.72rem; letter-spacing: 3px; text-transform: uppercase; color: var(--gold); }

/* CONTACT */
.contact-section { background: linear-gradient(160deg, var(--dark1), var(--dark2)); padding: 7rem 2rem; }
.contact-inner { max-width: 1000px; margin: 0 auto; }
.contact-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 5rem; margin-top: 3.5rem; align-items: start; }

.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
.form-group { margin-bottom: 1.2rem; }
.form-label { display: block; font-size: 0.62rem; letter-spacing: 2.5px; text-transform: uppercase; color: var(--gold); margin-bottom: 0.5rem; }
.form-input, .form-textarea, .form-select {
  width: 100%; background: var(--dark3);
  border: 1px solid var(--white-12); color: var(--white);
  padding: 0.85rem 1rem; font-size: 0.875rem; font-family: inherit; outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
.form-input:focus, .form-textarea:focus { border-color: var(--gold); box-shadow: 0 0 0 3px rgba(212,174,84,0.08); }
.form-input::placeholder, .form-textarea::placeholder { color: var(--white-40); }
.form-textarea { resize: vertical; min-height: 110px; }
.form-select { appearance: none; cursor: pointer; }
.form-submit {
  width: 100%; background: var(--gold); color: var(--black);
  border: none; padding: 1.1rem; font-size: 0.82rem; font-weight: 700;
  letter-spacing: 2.5px; text-transform: uppercase; cursor: pointer;
  font-family: inherit; transition: all 0.25s; margin-top: 0.5rem;
}
.form-submit:hover { background: var(--gold-light); box-shadow: 0 8px 24px rgba(212,174,84,0.3); transform: translateY(-1px); }
.form-promise { margin-top: 1rem; font-size: 0.75rem; color: var(--white-40); text-align: center; letter-spacing: 0.5px; }
.form-promise span { color: var(--gold); }

/* Form status messages */
.form-msg {
  padding: 1rem 1.5rem; margin-bottom: 1.5rem;
  font-size: 0.88rem; font-weight: 600; letter-spacing: 0.5px;
  border: 1px solid transparent;
}
.form-msg.success { background: rgba(42,110,58,0.2); border-color: rgba(42,110,58,0.5); color: #7fd694; }
.form-msg.error   { background: rgba(180,40,40,0.2); border-color: rgba(180,40,40,0.5); color: #f99; }

.contact-info-col h3 {
  font-family: 'Cormorant Garamond', serif;
  font-size: 1.8rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--white);
}
body:not(.lang-en) .contact-info-col h3 { font-family: 'Heebo', sans-serif; font-size: 1.5rem; font-weight: 700; }
.contact-info-col > p { font-size: 0.9rem; color: var(--white-70); line-height: 1.8; margin-bottom: 2rem; }
.contact-card {
  background: linear-gradient(135deg, var(--dark2), var(--grey2));
  padding: 1.5rem; margin-bottom: 1rem;
  border-right: 3px solid var(--blue-light);
  display: flex; gap: 1rem; align-items: flex-start;
  transition: transform 0.25s, box-shadow 0.25s;
}
body.lang-en .contact-card { border-right: none; border-left: 3px solid var(--blue-light); }
.contact-card:hover { transform: translateX(-4px); box-shadow: 4px 0 20px rgba(42,74,127,0.2); }
body.lang-en .contact-card:hover { transform: translateX(4px); }
.contact-card .ico { color: var(--gold); font-size: 1.2rem; flex-shrink: 0; margin-top: 0.1rem; }
.contact-card-text strong { display: block; font-size: 0.85rem; color: var(--white); margin-bottom: 0.2rem; }
.contact-card-text span, .contact-card-text a { font-size: 0.82rem; color: var(--white-70); line-height: 1.6; }
.contact-card-text a { color: var(--gold-light); }
.contact-card-text a:hover { color: var(--gold); }
.response-note {
  margin-top: 2rem; padding: 1.2rem 1.5rem;
  background: rgba(42,74,127,0.12);
  border: 1px solid rgba(42,74,127,0.25);
  font-size: 0.82rem; color: var(--white-70); line-height: 1.7; text-align: center;
}
.response-note strong { color: var(--gold); }

/* FOOTER */
footer {
  background: linear-gradient(180deg, var(--dark1), var(--black));
  border-top: 1px solid var(--white-06);
  padding: 2.5rem 2rem; text-align: center;
}
.footer-links { display: flex; gap: 2rem; justify-content: center; flex-wrap: wrap; margin-bottom: 1.2rem; }
.footer-links a { font-size: 0.75rem; color: var(--white-40); letter-spacing: 1px; transition: color 0.2s; }
.footer-links a:hover { color: var(--gold); }
.footer-copy { font-size: 0.7rem; color: var(--white-40); }

@media (max-width: 960px) {
  .nav-links { display: none; }
  .why-pillars, .impact-grid, .tiers-grid { grid-template-columns: 1fr; }
  .contact-grid { grid-template-columns: 1fr; gap: 3rem; }
  .form-row { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  #navbar { padding: 1rem 1.2rem; }
  .hero-title { font-size: 2.4rem; }
}
</style>
</head>
<body <?php body_class(); ?>>

<!-- NAVBAR -->
<nav id="navbar">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-brand">
    <div class="nav-star">✡</div>
    <div class="nav-brand-text">
      <div class="t1 he">טקס פרסי היכל התהילה</div>
      <div class="t1 en">Hall of Fame Awards</div>
      <div class="t2">Jewish Music · 2027</div>
    </div>
  </a>
  <ul class="nav-links">
    <li><a href="<?php echo esc_url(home_url('/')); ?>"><span class="he">בית</span><span class="en">Home</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/categories/')); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/support/')); ?>" class="active"><span class="he">תורמים</span><span class="en">Support Us</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/#ceremony')); ?>"><span class="he">הטקס</span><span class="en">Ceremony</span></a></li>
  </ul>
  <button id="lang-btn" onclick="switchLang()">ENGLISH</button>
</nav>

<!-- HERO -->
<section class="donor-hero">
  <div class="orb orb-1"></div>
  <div class="orb orb-2"></div>
  <div class="orb orb-3"></div>

  <span class="hero-eyebrow"><span class="he">שותפים לחזון</span><span class="en">Partners in Vision</span></span>

  <h1 class="hero-title">
    <span class="he">המוזיקה היהודית<br>ממתינה <span class="gold">להכרה שמגיעה לה</span></span>
    <span class="en">Jewish Music<br>Deserves <span class="gold">Its Moment of Recognition</span></span>
  </h1>

  <p class="hero-quote">
    <span class="he">"לאורך אלפי שנות גלות — שירנו. בכל לשון, בכל צליל, בכל כאב ושמחה. עכשיו הגיע הזמן לתת לצליל הזה את המקום הראוי לו בהיסטוריה."</span>
    <span class="en">"Through thousands of years of diaspora — we sang. In every language, every sound, every sorrow and joy. Now the time has come to give that sound its rightful place in history."</span>
  </p>

  <div class="hero-cta-group">
    <a href="#contact" class="btn-gold">
      <span class="he">דברו איתנו</span><span class="en">Get in Touch</span>
    </a>
    <a href="#tiers" class="btn-outline">
      <span class="he">רמות תמיכה</span><span class="en">Support Levels</span>
    </a>
  </div>

  <div class="hero-scroll-hint">
    <span><span class="he">גללו למטה</span><span class="en">Scroll down</span></span>
    <span class="scroll-arrow">↓</span>
  </div>
</section>

<!-- WHY NOW -->
<section class="why-now">
  <div class="why-now-inner">
    <div class="reveal">
      <span class="section-label"><span class="he">למה עכשיו?</span><span class="en">Why Now?</span></span>
      <h2 class="section-title">
        <span class="he">ארבע שנים לפני ההיסטוריה</span>
        <span class="en">Four Years Before History Is Made</span>
      </h2>
      <div class="rule"></div>
      <p class="why-now-text">
        <span class="he">המבנה הפיזי של היכל התהילה ייבנה — אך ההיסטוריה נכתבת עכשיו. טקס דצמבר 2027 הוא יריית הפתיחה הרשמית: אירוע ממלכתי שישודר חי בפני נשיא המדינה, ראשי המדינה ומיליוני צופים בעולם. תרומתך היום בונה את הבסיס שעליו יעמוד הכל.</span>
        <span class="en">The physical Hall of Fame will be built — but history is being written right now. The December 2027 ceremony is the official opening shot: a state event broadcast live before the President of Israel, national leaders, and millions of viewers worldwide. Your support today builds the foundation for everything that follows.</span>
      </p>
    </div>

    <div class="why-pillars">
      <div class="pillar reveal reveal-d1">
        <div class="pillar-icon">🎙️</div>
        <div class="pillar-title"><span class="he">מומנטום תקשורתי</span><span class="en">Media Momentum</span></div>
        <p class="pillar-text">
          <span class="he">בניית מודעות ציבורית הדרגתית בארץ ובעולם לפני הטקס הגדול.</span>
          <span class="en">Building gradual public awareness in Israel and worldwide ahead of the major ceremony.</span>
        </p>
      </div>
      <div class="pillar reveal reveal-d2">
        <div class="pillar-icon">🏛️</div>
        <div class="pillar-title"><span class="he">ביסוס הסמכות</span><span class="en">Authority Building</span></div>
        <p class="pillar-text">
          <span class="he">מיצוב היכל התהילה כסמכות המוזיקלית העליונה של העולם היהודי.</span>
          <span class="en">Positioning the Hall as the supreme musical authority of the Jewish world.</span>
        </p>
      </div>
      <div class="pillar reveal reveal-d3">
        <div class="pillar-icon">🌐</div>
        <div class="pillar-title"><span class="he">מורשת דיגיטלית</span><span class="en">Digital Legacy</span></div>
        <p class="pillar-text">
          <span class="he">ארכיון חי ורב-לשוני שישמר את יצירת האמנים לדורות הבאים.</span>
          <span class="en">A living multilingual archive preserving the artists' work for future generations.</span>
        </p>
      </div>
    </div>
  </div>
</section>

<!-- IMPACT NUMBERS -->
<section class="impact-section">
  <div class="impact-inner">
    <div class="reveal" style="text-align:center;">
      <span class="section-label"><span class="he">מה אנחנו בונים</span><span class="en">What We Are Building</span></span>
      <h2 class="section-title">
        <span class="he">המספרים מאחורי החזון</span>
        <span class="en">The Numbers Behind the Vision</span>
      </h2>
      <div class="rule"></div>
    </div>
    <div class="impact-grid">
      <div class="impact-box reveal reveal-d1">
        <div class="impact-num">12</div>
        <div class="impact-label he">קטגוריות פרס במחזור הראשון</div>
        <div class="impact-label en">Award categories in the inaugural class</div>
      </div>
      <div class="impact-box reveal reveal-d2">
        <div class="impact-num">2027</div>
        <div class="impact-label he">הטקס הממלכתי הראשון — דצמבר, פתח תקווה</div>
        <div class="impact-label en">First state ceremony — December, Petah Tikva</div>
      </div>
      <div class="impact-box reveal reveal-d3">
        <div class="impact-num">150</div>
        <div class="impact-label he">שנה לעיר פתח תקווה — המסגרת החגיגית</div>
        <div class="impact-label en">Years of Petah Tikva — the celebratory backdrop</div>
      </div>
      <div class="impact-box reveal reveal-d1">
        <div class="impact-num">∞</div>
        <div class="impact-label he">דורות של מוזיקה יהודית שיוכרו לנצח</div>
        <div class="impact-label en">Generations of Jewish music recognized forever</div>
      </div>
    </div>
  </div>
</section>

<!-- TIERS -->
<section class="tiers-section" id="tiers">
  <div class="tiers-header reveal">
    <span class="section-label"><span class="he">רמות שותפות</span><span class="en">Partnership Levels</span></span>
    <h2 class="section-title">
      <span class="he">כל תמיכה בונה פרק בהיסטוריה</span>
      <span class="en">Every Contribution Writes a Chapter in History</span>
    </h2>
    <div class="rule"></div>
    <p style="color:var(--white-70); font-size:0.9rem; max-width:600px; margin:0 auto; line-height:1.8;">
      <span class="he">אין כאן כפתור תשלום — כל שותפות מתחילה בשיחה. צרו קשר ונתאים יחד את הדרך הנכונה.</span>
      <span class="en">There is no payment button here — every partnership begins with a conversation. Get in touch and we'll find the right path together.</span>
    </p>
  </div>

  <div class="tiers-grid">
    <!-- Friend -->
    <div class="tier-card reveal reveal-d1">
      <div class="tier-level"><span class="he">רמה א'</span><span class="en">Level I</span></div>
      <div class="tier-name he">חבר</div>
      <div class="tier-name en">Friend</div>
      <div class="tier-price">$1K</div>
      <div class="tier-price-note he">תרומה שנתית</div>
      <div class="tier-price-note en">Annual contribution</div>
      <div class="tier-impact">
        <span class="he">"תרומתך מאפשרת את הבסיס הדיגיטלי — האתר, הארכיון, והנוכחות הציבורית שמגיעה לפני הטקס."</span>
        <span class="en">"Your contribution enables the digital foundation — the website, archive, and public presence leading up to the ceremony."</span>
      </div>
      <ul class="tier-benefits">
        <li><span class="check">✦</span><span class="he">הזמנה לטקס הענקת הפרסים 2027</span><span class="en">Invitation to the 2027 award ceremony</span></li>
        <li><span class="check">✦</span><span class="he">שמכם בתוכניית הטקס הרשמית</span><span class="en">Your name in the official ceremony programme</span></li>
        <li><span class="check">✦</span><span class="he">עדכונים שוטפים ותוכן בלעדי</span><span class="en">Regular updates and exclusive content</span></li>
        <li><span class="check">✦</span><span class="he">גישה לאחורי הקלעים הדיגיטליים</span><span class="en">Digital behind-the-scenes access</span></li>
      </ul>
      <button class="tier-cta" onclick="scrollToContact()">
        <span class="he">צרו קשר</span><span class="en">Get in Touch</span>
      </button>
    </div>

    <!-- Ambassador -->
    <div class="tier-card featured reveal reveal-d2">
      <div class="tier-top-badge he">הנפוץ ביותר</div>
      <div class="tier-level"><span class="he">רמה ב'</span><span class="en">Level II</span></div>
      <div class="tier-name he">שגריר</div>
      <div class="tier-name en">Ambassador</div>
      <div class="tier-price">$10K</div>
      <div class="tier-price-note he">תרומה שנתית</div>
      <div class="tier-price-note en">Annual contribution</div>
      <div class="tier-impact">
        <span class="he">"כשגריר אתה לא רק תומך — אתה חלק מהסיפור. שמך יהיה קשור לאירוע הממלכתי הגדול ביותר של המוזיקה היהודית."</span>
        <span class="en">"As an Ambassador you are not just a supporter — you are part of the story. Your name will be tied to the greatest state event in Jewish music history."</span>
      </div>
      <ul class="tier-benefits">
        <li><span class="check">✦</span><span class="he">כל הטבות "חבר"</span><span class="en">All "Friend" benefits</span></li>
        <li><span class="check">✦</span><span class="he">שולחן מכובד בטקס הענקת הפרסים</span><span class="en">Table of honour at the award ceremony</span></li>
        <li><span class="check">✦</span><span class="he">פגישה אישית עם יו"ר מיתר והנהלה</span><span class="en">Personal meeting with Mitar leadership</span></li>
        <li><span class="check">✦</span><span class="he">לוח הכרה על קיר היכל התהילה</span><span class="en">Recognition plaque on the Hall's wall</span></li>
        <li><span class="check">✦</span><span class="he">הזמנות VIP לכל אירועי ההיכל</span><span class="en">VIP invitations to all Hall events</span></li>
        <li><span class="check">✦</span><span class="he">אזכור בכל הודעות התקשורת</span><span class="en">Mention in all press releases</span></li>
      </ul>
      <button class="tier-cta" onclick="scrollToContact()">
        <span class="he">צרו קשר</span><span class="en">Get in Touch</span>
      </button>
    </div>

    <!-- Founding Partner -->
    <div class="tier-card reveal reveal-d3">
      <div class="tier-level"><span class="he">רמה ג'</span><span class="en">Level III</span></div>
      <div class="tier-name he">שותף מייסד</div>
      <div class="tier-name en">Founding Partner</div>
      <div class="tier-price">$50K+</div>
      <div class="tier-price-note he">תרומה שנתית</div>
      <div class="tier-price-note en">Annual contribution</div>
      <div class="tier-impact">
        <span class="he">"שותפי המייסדים הם אלה שהיסטוריה תזכור. שמכם יהיה חלק בלתי נפרד מהמורשת של היכל התהילה לנצח."</span>
        <span class="en">"Founding Partners are those history will remember. Your name will be an inseparable part of the Hall of Fame's legacy — forever."</span>
      </div>
      <ul class="tier-benefits">
        <li><span class="check">✦</span><span class="he">כל הטבות "שגריר"</span><span class="en">All "Ambassador" benefits</span></li>
        <li><span class="check">✦</span><span class="he">חברות בחבר הנאמנים העולמי</span><span class="en">Seat on the World Board of Trustees</span></li>
        <li><span class="check">✦</span><span class="he">זכות שמייה על אחד מפרסי ההיכל</span><span class="en">Naming rights for one of the Hall's awards</span></li>
        <li><span class="check">✦</span><span class="he">השפעה ישירה על הכיוון האסטרטגי</span><span class="en">Direct influence on strategic direction</span></li>
        <li><span class="check">✦</span><span class="he">מיתוג בולט בכל אירועי ההיכל</span><span class="en">Prominent branding at all Hall events</span></li>
        <li><span class="check">✦</span><span class="he">נוכחות קבועה בפרסומים הבינלאומיים</span><span class="en">Permanent presence in all international publications</span></li>
      </ul>
      <button class="tier-cta" onclick="scrollToContact()">
        <span class="he">צרו קשר</span><span class="en">Get in Touch</span>
      </button>
    </div>
  </div>
</section>

<!-- VISION QUOTE -->
<section class="vision-quote-section reveal">
  <p class="big-quote">
    <span class="he">"המוזיקה היהודית היא הגשר המחבר בין עבר, הווה ועתיד — שפה ללא גבולות שנדדה עם העם היהודי בכל תפוצותיו. עזרו לנו לתת לה את הבית הקבוע שמגיע לה."</span>
    <span class="en">"Jewish music is the bridge connecting past, present and future — a language without borders that travelled with the Jewish people through every diaspora. Help us give it the permanent home it deserves."</span>
  </p>
  <div class="quote-attr he">— עמותת מיתר, היכל התהילה של המוזיקה היהודית</div>
  <div class="quote-attr en">— Mitar Association, Jewish Music Hall of Fame</div>
</section>

<!-- CONTACT -->
<section class="contact-section" id="contact">
  <div class="contact-inner">
    <div class="reveal">
      <span class="section-label"><span class="he">התחילו את השיחה</span><span class="en">Start the Conversation</span></span>
      <h2 class="section-title">
        <span class="he">נשמח לשמוע מכם</span>
        <span class="en">We'd Love to Hear From You</span>
      </h2>
      <div class="rule" style="margin:1.2rem 0 0;"></div>
    </div>

    <div class="contact-grid reveal reveal-d1">

      <!-- FORM -->
      <div class="contact-form-wrap">
        <?php if ($form_status === 'success') : ?>
          <div class="form-msg success">
            <span class="he">✓ הודעתכם נשלחה! נחזור אליכם תוך 48 שעות.</span>
            <span class="en">✓ Your message was sent! We'll be in touch within 48 hours.</span>
          </div>
        <?php elseif ($form_status === 'error') : ?>
          <div class="form-msg error">
            <span class="he">⚠ אירעה שגיאה — בדקו שהאימייל תקין ונסו שוב.</span>
            <span class="en">⚠ Something went wrong — please check your email and try again.</span>
          </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <?php wp_nonce_field('hof_contact_nonce', 'hof_nonce'); ?>
          <input type="hidden" name="action" value="hof_contact" />
          <div class="form-row">
            <div class="form-group">
              <label class="form-label"><span class="he">שם פרטי</span><span class="en">First Name</span></label>
              <input type="text" name="first_name" class="form-input" required placeholder="" data-he="שם פרטי" data-en="First name" />
            </div>
            <div class="form-group">
              <label class="form-label"><span class="he">שם משפחה</span><span class="en">Last Name</span></label>
              <input type="text" name="last_name" class="form-input" required placeholder="" data-he="שם משפחה" data-en="Last name" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label"><span class="he">אימייל</span><span class="en">Email</span></label>
            <input type="email" name="email" class="form-input" required placeholder="" data-he="your@email.com" data-en="your@email.com" />
          </div>
          <div class="form-group">
            <label class="form-label"><span class="he">ארגון / חברה (אופציונלי)</span><span class="en">Organisation / Company (optional)</span></label>
            <input type="text" name="org" class="form-input" placeholder="" data-he="שם הארגון" data-en="Organisation name" />
          </div>
          <div class="form-group">
            <label class="form-label"><span class="he">רמת שותפות מועדפת</span><span class="en">Preferred partnership level</span></label>
            <select name="level" class="form-select form-input">
              <option value="" disabled selected>בחרו רמה...</option>
              <option value="friend">Friend / חבר — $1K</option>
              <option value="ambassador">Ambassador / שגריר — $10K</option>
              <option value="founding">Founding Partner / שותף מייסד — $50K+</option>
              <option value="other">אחר / Open to discussion</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label"><span class="he">הודעה</span><span class="en">Message</span></label>
            <textarea name="message" class="form-textarea" placeholder="" data-he="ספרו לנו על עצמכם וקשרכם למוזיקה היהודית..." data-en="Tell us about yourself and your connection to Jewish music..."></textarea>
          </div>
          <button type="submit" class="form-submit">
            <span class="he">שלחו הודעה ←</span>
            <span class="en">Send Message →</span>
          </button>
          <p class="form-promise">
            <span class="he">⏱ <span>חוזרים אליכם תוך 48 שעות</span> — בסודיות מוחלטת</span>
            <span class="en">⏱ We respond within <span>48 hours</span> — in complete confidence</span>
          </p>
        </form>
      </div>

      <!-- INFO -->
      <div class="contact-info-col">
        <h3><span class="he">למה לפנות?</span><span class="en">Why Reach Out?</span></h3>
        <p>
          <span class="he">אנחנו לא מחפשים רק תרומה — אנחנו מחפשים שותפים שמאמינים בכוחה של המוזיקה היהודית לאחד ולהנציח. כל שיחה היא הזדמנות לגלות ביחד מה הדרך הנכונה.</span>
          <span class="en">We are not just looking for a donation — we are looking for partners who believe in the power of Jewish music to unite and immortalize. Every conversation is an opportunity to discover the right path together.</span>
        </p>

        <div class="contact-card">
          <span class="ico">📧</span>
          <div class="contact-card-text">
            <strong><span class="he">אימייל ישיר</span><span class="en">Direct Email</span></strong>
            <a href="mailto:info@jewishmusichalloffame.org">info@jewishmusichalloffame.org</a>
          </div>
        </div>

        <div class="contact-card">
          <span class="ico">🏛️</span>
          <div class="contact-card-text">
            <strong><span class="he">הגוף המפעיל</span><span class="en">Operating Body</span></strong>
            <span class="he">עמותת מיתר היכל התהילה של המוזיקה היהודית</span>
            <span class="en">Mitar — Jewish Music Hall of Fame Association</span>
          </div>
        </div>

        <div class="contact-card">
          <span class="ico">📍</span>
          <div class="contact-card-text">
            <strong><span class="he">מיקום</span><span class="en">Location</span></strong>
            <span class="he">פתח תקווה, ישראל</span>
            <span class="en">Petah Tikva, Israel</span>
          </div>
        </div>

        <div class="response-note">
          <span class="he">🔒 כל הפרטים נשמרים <strong>בסודיות מוחלטת</strong>. לא משתפים, לא מפרסמים ללא אישורכם.</span>
          <span class="en">🔒 All details are kept in <strong>complete confidence</strong>. Never shared or published without your approval.</span>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-links">
    <a href="<?php echo esc_url(home_url('/')); ?>"><span class="he">דף הבית</span><span class="en">Home</span></a>
    <a href="<?php echo esc_url(home_url('/categories/')); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a>
    <a href="<?php echo esc_url(home_url('/support/')); ?>"><span class="he">תמיכה</span><span class="en">Support Us</span></a>
    <a href="<?php echo esc_url(home_url('/#process')); ?>"><span class="he">תהליך הבחירה</span><span class="en">Selection</span></a>
  </div>
  <div class="footer-copy">© 2026 ✡ <span class="he">טקס פרסי היכל התהילה של המוזיקה היהודית</span><span class="en">Jewish Music Hall of Fame Awards</span></div>
</footer>

<script>
let lang = 'he';

function switchLang() {
  lang = lang === 'he' ? 'en' : 'he';
  const body = document.body;
  const html = document.getElementById('html-root');
  const btn  = document.getElementById('lang-btn');
  if (lang === 'en') {
    body.classList.add('lang-en'); html.lang = 'en'; html.dir = 'ltr';
    btn.textContent = 'עברית';
    localStorage.setItem('lang', 'en');
    document.querySelectorAll('[data-en]').forEach(el => { el.placeholder = el.dataset.en; });
  } else {
    body.classList.remove('lang-en'); html.lang = 'he'; html.dir = 'rtl';
    btn.textContent = 'ENGLISH';
    localStorage.setItem('lang', 'he');
    document.querySelectorAll('[data-he]').forEach(el => { el.placeholder = el.dataset.he; });
  }
}

const savedLang = localStorage.getItem('lang');
if (savedLang === 'en') {
  lang = 'en';
  document.body.classList.add('lang-en');
  document.getElementById('html-root').lang = 'en';
  document.getElementById('html-root').dir = 'ltr';
  document.getElementById('lang-btn').textContent = 'עברית';
  document.querySelectorAll('[data-en]').forEach(el => { el.placeholder = el.dataset.en; });
} else {
  document.querySelectorAll('[data-he]').forEach(el => { el.placeholder = el.dataset.he; });
}

function scrollToContact() {
  document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
}

const io = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('on'); });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));
</script>
<?php wp_footer(); ?>
</body>
</html>
