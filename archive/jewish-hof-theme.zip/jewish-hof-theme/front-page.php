<?php defined('ABSPATH') || exit; ?>
<!DOCTYPE html>
<html lang="he" dir="rtl" id="html-root">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>טקס פרסי היכל התהילה של המוזיקה היהודית | Jewish Music Hall of Fame Awards</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Playfair+Display:wght@700;900&family=Heebo:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<style>
:root {
  --gold:#D4AE54;--blue:#2A4A7F;--blue-light:#3D6BAF;--blue-glow:rgba(42,74,127,0.25);
  --grey1:#1C1E24;--grey2:#252830;--grey3:#2E3240;
  --gold-light:#E2C46A;--gold-dark:#8A6E28;--gold-glow:rgba(201,168,76,0.18);
  --black:#0C0E14;--dark1:#12151E;--dark2:#1A1F2E;--dark3:#222840;--dark4:#2C2C2C;
  --white:#F6F1E8;--white-70:rgba(244,239,230,0.70);--white-40:rgba(244,239,230,0.40);
  --white-12:rgba(244,239,230,0.12);--white-06:rgba(244,239,230,0.06);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html{scroll-behavior:smooth;}
body{background:var(--black);color:var(--white);font-family:'Heebo',sans-serif;font-weight:400;line-height:1.6;overflow-x:hidden;direction:rtl;}
body.lang-en{direction:ltr;font-family:'Cormorant Garamond',serif;font-size:106%;letter-spacing:0.01em;}
::-webkit-scrollbar{width:5px;}::-webkit-scrollbar-track{background:var(--black);}::-webkit-scrollbar-thumb{background:var(--gold-dark);}
a{text-decoration:none;color:inherit;}img{display:block;max-width:100%;}
.gold{color:var(--gold);}.center{text-align:center;}.wrap{max-width:1200px;margin:0 auto;padding:0 2rem;}
.eyebrow{display:block;font-size:0.65rem;letter-spacing:5px;text-transform:uppercase;color:var(--gold);margin-bottom:0.9rem;animation:labelGlow 3s ease-in-out infinite;text-shadow:0 0 12px rgba(212,174,84,0.3);}
.rule{width:48px;height:2px;background:linear-gradient(90deg,transparent,var(--gold),var(--blue-light),var(--gold),transparent)!important;background-size:200% auto!important;animation:shimmer 3s linear infinite;margin:1.2rem 0 2rem;}
.rule.center{margin-left:auto;margin-right:auto;}
.section-title{font-family:'Playfair Display',serif;font-size:clamp(2rem,4vw,3rem);font-weight:700;line-height:1.15;text-shadow:0 2px 20px rgba(42,74,127,0.15);}
body:not(.lang-en) .section-title{font-family:'Heebo',sans-serif;font-weight:800;}
.btn{display:inline-block;padding:0.85rem 2.2rem;font-size:0.75rem;letter-spacing:2.5px;text-transform:uppercase;font-family:inherit;cursor:pointer;transition:all 0.22s;border:none;}
.btn-gold{background:var(--gold);color:var(--black);font-weight:700;}
.btn-gold:hover{background:var(--gold-light);transform:translateY(-2px);box-shadow:0 10px 30px rgba(201,168,76,0.25);animation:goldPulse 1.5s ease-in-out infinite;}
.btn-outline{background:transparent;color:var(--white-70);border:1px solid var(--white-40);}
.btn-outline:hover{border-color:var(--gold);color:var(--gold);}
.he{display:block;}.en{display:none;}
body.lang-en .section-title,body.lang-en .hero-h1,body.lang-en .support-banner h2{font-family:'Cormorant Garamond',serif;font-weight:600;letter-spacing:0.02em;}
body.lang-en .he{display:none!important;}body.lang-en .en{display:block!important;}
.he-inline{display:inline;}.en-inline{display:none;}
body.lang-en .he-inline{display:none!important;}body.lang-en .en-inline{display:inline!important;}
.reveal{opacity:0;transform:translateY(36px);transition:opacity 0.75s ease,transform 0.75s ease;}
.reveal.on{opacity:1;transform:none;}
.reveal-d1{transition-delay:0.1s;}.reveal-d2{transition-delay:0.2s;}.reveal-d3{transition-delay:0.3s;}.reveal-d4{transition-delay:0.4s;}
body{padding-bottom:100px;}
#navbar{position:fixed;inset:0 0 auto;z-index:900;display:flex;align-items:center;justify-content:space-between;padding:1.2rem 2.5rem;transition:background 0.35s,border-color 0.35s;direction:ltr;}
#navbar.solid{background:linear-gradient(90deg,rgba(12,14,20,0.97),rgba(18,21,34,0.97))!important;border-bottom:1px solid rgba(212,174,84,0.22)!important;backdrop-filter:blur(8px);}
.nav-brand{display:flex;align-items:center;gap:0.75rem;}
.nav-star{width:40px;height:40px;border:1.5px solid var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.15rem;flex-shrink:0;box-shadow:0 0 0 0 rgba(42,74,127,0);transition:box-shadow 0.3s;}
.nav-star:hover{box-shadow:0 0 16px rgba(42,74,127,0.5);}
.nav-brand-text .t1{font-size:0.8rem;font-weight:700;color:var(--gold);}.nav-brand-text .t2{font-size:0.6rem;font-weight:300;color:var(--white-40);letter-spacing:2px;text-transform:uppercase;}
.nav-links{display:flex;gap:2rem;list-style:none;}
.nav-links a{font-size:0.72rem;letter-spacing:1.5px;text-transform:uppercase;color:var(--white-70);transition:color 0.2s;}
.nav-links a:hover{color:var(--gold);}
#lang-btn{background:transparent;border:1px solid var(--gold);color:var(--gold);font-size:0.7rem;letter-spacing:2px;padding:0.38rem 1rem;cursor:pointer;font-family:inherit;transition:all 0.2s;}
#lang-btn:hover{background:var(--gold);color:var(--black);}
#hero{position:relative;height:100vh;min-height:720px;display:flex;align-items:center;justify-content:center;padding-top:75px;padding-bottom:20px;overflow:hidden;}
.hero-bg{position:absolute;inset:0;background:radial-gradient(ellipse 70% 55% at 50% 55%,rgba(42,74,127,0.18) 0%,transparent 65%),radial-gradient(ellipse 70% 55% at 50% 55%,rgba(212,174,84,0.07) 0%,transparent 65%),linear-gradient(175deg,rgba(12,14,20,0.42) 0%,rgba(12,14,20,0.84) 100%),url('https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=1800&q=80') center/cover no-repeat!important;}
.hero-bg::after{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);}
#particles{position:absolute;inset:0;pointer-events:none;overflow:hidden;}
.pt{position:absolute;border-radius:50%;background:var(--gold);opacity:0;animation:ptrise linear infinite;}
@keyframes ptrise{0%{transform:translateY(105vh) scale(0);opacity:0;}8%{opacity:0.55;}92%{opacity:0.2;}100%{transform:translateY(-80px) scale(1.4);opacity:0;}}
.hero-body{position:relative;z-index:2;text-align:center;padding:0 1.5rem;max-width:860px;width:100%;}
.hero-badge{display:inline-block;border:1px solid var(--gold);color:var(--gold);font-size:0.65rem;letter-spacing:5px;text-transform:uppercase;padding:0.35rem 1.4rem;margin-bottom:1.2rem;animation:fadeUp 1s ease both;}
.hero-h1{font-family:'Playfair Display',serif;font-size:clamp(3rem,8vw,6.5rem);font-weight:900;line-height:1.05;margin-bottom:0.7rem;animation:fadeUp 1s 0.15s ease both;}
body:not(.lang-en) .hero-h1{font-family:'Heebo',sans-serif;}
.hero-sub{font-size:clamp(1rem,2.2vw,1.25rem);font-weight:300;color:var(--white-70);max-width:580px;margin:0 auto 1.4rem;line-height:1.75;animation:fadeUp 1s 0.3s ease both;}
.hero-ctas{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;animation:fadeUp 1s 0.45s ease both;}
#countdown-bar{position:fixed!important;bottom:0!important;left:0!important;right:0!important;z-index:999!important;display:flex;align-items:center;justify-content:center;gap:4rem;padding:1.4rem 2.5rem;direction:ltr;background:linear-gradient(90deg,rgba(12,14,20,0.95),rgba(18,21,34,0.95),rgba(12,14,20,0.95))!important;border-top:1px solid rgba(42,74,127,0.35)!important;flex-wrap:wrap;}
.cd-event{text-align:center;}.cd-event .ev-title{font-size:0.78rem;font-weight:600;color:var(--white);letter-spacing:0.5px;}.cd-event .ev-sub{font-size:0.6rem;color:var(--white-40);margin-top:0.2rem;letter-spacing:1px;}
.cd-units{display:flex;align-items:flex-start;gap:1.8rem;direction:ltr;}
.cd-unit{text-align:center;min-width:44px;}
.cd-num{font-family:'Playfair Display',serif;font-size:2rem;font-weight:700;color:var(--gold);line-height:1;text-shadow:0 0 20px rgba(212,174,84,0.4);}
.cd-lbl{font-size:0.55rem;letter-spacing:2px;text-transform:uppercase;color:var(--white-40);margin-top:0.25rem;}
.cd-colon{font-size:1.8rem;color:var(--gold-dark);line-height:1;padding-top:0.1rem;}
#about{background:linear-gradient(160deg,var(--dark1) 0%,var(--dark2) 60%,var(--grey2) 100%)!important;padding:8rem 2rem;}
.about-grid{display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;max-width:1200px;margin:0 auto;}
.about-copy p{font-size:1rem;color:var(--white-70);line-height:1.9;margin-bottom:1.4rem;}
.about-stats{display:grid;grid-template-columns:1fr 1fr;gap:2px;}
.stat{background:linear-gradient(135deg,var(--dark2),var(--grey2))!important;padding:2rem 1.8rem;border-top:2px solid transparent;transition:border-color 0.3s,transform 0.3s,box-shadow 0.3s!important;}
.stat:hover{border-top-color:var(--gold);transform:translateY(-4px)!important;box-shadow:0 12px 32px rgba(42,74,127,0.2),0 4px 12px rgba(212,174,84,0.12)!important;}
.stat-n{font-family:'Playfair Display',serif;font-size:2.8rem;font-weight:700;color:var(--gold);line-height:1;}
.stat-d{font-size:0.8rem;color:var(--white-40);margin-top:0.5rem;line-height:1.5;}
#categories{background:var(--black);padding:8rem 2rem;}
.cat-header{max-width:1200px;margin:0 auto 4rem;}
.cat-grid{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(255px,1fr));gap:2px;}
.cat-card{background:linear-gradient(135deg,var(--dark2),var(--grey2))!important;padding:2.2rem 1.8rem 3rem;position:relative;overflow:hidden;transition:transform 0.3s,border-color 0.3s,box-shadow 0.3s!important;border-bottom:2px solid transparent;cursor:pointer;}
.cat-card::before{content:'';position:absolute;inset:0;background:linear-gradient(135deg,var(--gold-glow),transparent 70%);opacity:0;transition:opacity 0.28s;}
.cat-card:hover{transform:translateY(-5px);border-bottom-color:var(--gold);box-shadow:0 8px 32px rgba(42,74,127,0.25),0 2px 8px rgba(212,174,84,0.1)!important;}
.cat-card:hover::before{opacity:1;}
.cat-num{font-size:0.58rem;letter-spacing:3px;color:var(--gold);margin-bottom:0.8rem;}
.cat-icon{font-size:2rem;margin-bottom:0.8rem;display:block;}
.cat-name{font-size:1.05rem;font-weight:700;margin-bottom:0.4rem;}
.cat-sub{font-size:0.78rem;color:var(--white-40);line-height:1.5;}
.cat-arrow{position:absolute;bottom:1.3rem;right:1.8rem;color:var(--gold-dark);font-size:1.1rem;transition:transform 0.25s,color 0.25s;}
body.lang-en .cat-arrow{right:auto;left:1.8rem;}
.cat-card:hover .cat-arrow{color:var(--gold);transform:translateX(4px);}
body:not(.lang-en) .cat-card:hover .cat-arrow{transform:translateX(-4px);}
.badge-pc{position:absolute;top:1rem;left:1rem;background:var(--gold);color:var(--black);font-size:0.52rem;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;padding:0.22rem 0.6rem;}
body.lang-en .badge-pc{left:auto;right:1rem;}
#ceremony{background:linear-gradient(145deg,var(--dark2) 0%,var(--grey2) 50%,var(--dark1) 100%)!important;padding:8rem 2rem;}
.ceremony-grid{display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;max-width:1200px;margin:0 auto;}
.ceremony-img-wrap{position:relative;aspect-ratio:4/3;overflow:hidden;}
.ceremony-img-wrap img{width:100%;height:100%;object-fit:cover;filter:grayscale(25%);transition:filter 0.5s;}
.ceremony-img-wrap:hover img{filter:none;}
.ceremony-img-wrap::after{content:'';position:absolute;inset:0;border:1px solid rgba(201,168,76,0.28);pointer-events:none;}
.ceremony-badge{position:absolute;bottom:1.2rem;right:1.2rem;background:rgba(8,8,8,0.92);border:1px solid var(--gold);padding:0.8rem 1.1rem;text-align:center;}
body.lang-en .ceremony-badge{right:auto;left:1.2rem;}
.ceremony-badge .cb-date{font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--gold);font-weight:700;line-height:1;}
.ceremony-badge .cb-place{font-size:0.58rem;letter-spacing:2px;text-transform:uppercase;color:var(--white-40);margin-top:0.3rem;}
.ceremony-list{list-style:none;margin-top:2rem;}
.ceremony-list li{display:flex;gap:1rem;padding:0.95rem 0;border-bottom:1px solid var(--white-12);font-size:0.88rem;color:var(--white-70);}
.ceremony-list li .ico{color:var(--gold);flex-shrink:0;margin-top:0.1rem;}
.ceremony-list li strong{display:block;color:var(--white);font-size:0.9rem;margin-bottom:0.15rem;}
#process{background:var(--black);padding:8rem 2rem;}
.process-inner{max-width:900px;margin:0 auto;}
.steps{margin-top:3.5rem;position:relative;}
.steps::before{content:'';position:absolute;top:0;bottom:0;right:1.3rem;width:1px;background:linear-gradient(to bottom,transparent,var(--blue-light),var(--blue),transparent)!important;}
body.lang-en .steps::before{right:auto;left:1.3rem;}
.step{display:flex;gap:2.5rem;margin-bottom:2.8rem;align-items:flex-start;}
body.lang-en .step{flex-direction:row-reverse;}
.step-dot{width:40px;height:40px;flex-shrink:0;background:linear-gradient(135deg,var(--dark2),var(--grey3))!important;border:2px solid var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',serif;font-size:1rem;font-weight:700;color:var(--gold);box-shadow:0 0 0 4px rgba(42,74,127,0.12);transition:box-shadow 0.3s,transform 0.3s;}
.step:hover .step-dot{box-shadow:0 0 0 6px rgba(42,74,127,0.25),0 0 20px rgba(212,174,84,0.2);transform:scale(1.08);}
.step-body h4{font-size:1rem;font-weight:700;color:var(--white);margin-bottom:0.45rem;}
.step-body p{font-size:0.855rem;color:var(--white-70);line-height:1.75;}
#support{background:linear-gradient(135deg,var(--grey2) 0%,var(--dark3) 50%,var(--grey1) 100%)!important;border-top:1px solid rgba(42,74,127,0.3)!important;border-bottom:1px solid rgba(42,74,127,0.3)!important;padding:7rem 2rem;text-align:center;}
#support p{max-width:580px;margin:0 auto 2.8rem;color:var(--white-70);font-size:1rem;line-height:1.8;}
.support-ctas{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;}
#newsletter{background:linear-gradient(160deg,var(--dark2),var(--grey2))!important;padding:5rem 2rem;text-align:center;}
#newsletter p{color:var(--white-40);font-size:0.9rem;margin-top:0.4rem;margin-bottom:2rem;}
.nl-form{display:flex;max-width:500px;margin:0 auto;}
.nl-form input{flex:1;background:var(--dark3);border:1px solid rgba(201,168,76,0.28);border-left:none;color:var(--white);padding:0.85rem 1.2rem;font-size:0.875rem;font-family:inherit;outline:none;}
body.lang-en .nl-form input{border-left:1px solid rgba(201,168,76,0.28);border-right:none;}
.nl-form input::placeholder{color:var(--white-40);}
.nl-form input:focus{border-color:var(--gold);}
.nl-form button{background:var(--gold);color:var(--black);border:none;padding:0 1.6rem;font-size:0.72rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;cursor:pointer;font-family:inherit;white-space:nowrap;transition:background 0.2s;}
.nl-form button:hover{background:var(--gold-light);}
footer{background:linear-gradient(180deg,var(--dark1),var(--black))!important;border-top:1px solid var(--white-06);padding:4.5rem 2rem 2rem;}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:3rem;max-width:1200px;margin:0 auto;padding-bottom:3rem;border-bottom:1px solid var(--white-06);}
.footer-about .fa-logo{font-size:1rem;font-weight:700;color:var(--gold);margin-bottom:0.9rem;}
.footer-about p{font-size:0.8rem;color:var(--white-40);line-height:1.7;max-width:260px;}
.footer-col h5{font-size:0.6rem;letter-spacing:3px;text-transform:uppercase;color:var(--gold);margin-bottom:1.2rem;}
.footer-col ul{list-style:none;}.footer-col ul li{margin-bottom:0.65rem;}
.footer-col ul li a{font-size:0.83rem;color:var(--white-70);transition:color 0.2s;}
.footer-col ul li a:hover{color:var(--gold);}
.footer-bottom{max-width:1200px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;padding-top:1.5rem;font-size:0.72rem;color:var(--white-40);flex-wrap:wrap;gap:0.5rem;}
@keyframes fadeUp{from{opacity:0;transform:translateY(28px);}to{opacity:1;transform:none;}}
@keyframes shimmer{0%{background-position:-200% center;}100%{background-position:200% center;}}
@keyframes goldPulse{0%,100%{box-shadow:0 0 0 0 rgba(212,174,84,0);}50%{box-shadow:0 0 18px 4px rgba(212,174,84,0.28);}}
@keyframes labelGlow{0%,100%{opacity:0.85;letter-spacing:5px;}50%{opacity:1;letter-spacing:5.5px;}}
@keyframes ptrise{0%{transform:translateY(105vh) scale(0);opacity:0;}8%{opacity:0.55;}92%{opacity:0.2;}100%{transform:translateY(-80px) scale(1.4);opacity:0;}}
@media(max-width:960px){.about-grid,.ceremony-grid{grid-template-columns:1fr;gap:3rem;}.footer-grid{grid-template-columns:1fr 1fr;}.nav-links{display:none;}}
@media(max-width:600px){#navbar{padding:1rem 1.2rem;}.hero-h1{font-size:2.4rem;}.cat-grid{grid-template-columns:1fr 1fr;}.footer-grid{grid-template-columns:1fr;}.nl-form{flex-direction:column;}.nl-form input{border-left:1px solid rgba(201,168,76,0.28)!important;border-bottom:none;}#countdown-bar{gap:1.5rem;}}
</style>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav id="navbar">
  <a href="<?php echo home_url('/'); ?>" class="nav-brand">
    <div class="nav-star">✡</div>
    <div class="nav-brand-text">
      <div class="t1 he">טקס פרסי היכל התהילה</div>
      <div class="t1 en" style="font-size:0.72rem;">Hall of Fame Awards</div>
      <div class="t2">Jewish Music Hall of Fame Awards · 2027</div>
    </div>
  </a>
  <ul class="nav-links">
    <li><a href="#about"><span class="he">אודות</span><span class="en">About</span></a></li>
    <li><a href="<?php echo home_url('/categories/'); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a></li>
    <li><a href="#ceremony"><span class="he">הטקס</span><span class="en">Ceremony</span></a></li>
    <li><a href="#process"><span class="he">תהליך הבחירה</span><span class="en">Selection</span></a></li>
    <li><a href="<?php echo home_url('/support/'); ?>"><span class="he">תמיכה</span><span class="en">Support</span></a></li>
  </ul>
  <button id="lang-btn" onclick="switchLang()">ENGLISH</button>
</nav>

<section id="hero">
  <div class="hero-bg"></div>
  <div id="particles"></div>
  <div class="hero-body">
    <span class="hero-badge">
      <span class="he">מחזור ראשון · 2027</span>
      <span class="en">Inaugural Class · 2027</span>
    </span>
    <h1 class="hero-h1">
      <span class="he">טקס פרסי היכל התהילה<br><span class="gold">של המוזיקה היהודית</span></span>
      <span class="en">The Jewish Music<br><span class="gold">Hall of Fame Awards</span></span>
    </h1>
    <p class="hero-sub">
      <span class="he">הכרה ממלכתית ומכובדת ליוצרים ומבצעים שעיצבו את פס הקול היהודי לדורותיו — בישראל ובעולם</span>
      <span class="en">A prestigious state recognition for the creators and performers who shaped the Jewish sound for generations — in Israel and across the world</span>
    </p>
    <div class="hero-ctas">
      <a href="<?php echo home_url('/categories/'); ?>" class="btn btn-gold">
        <span class="he">הקטגוריות</span><span class="en">The Categories</span>
      </a>
      <a href="<?php echo home_url('/support/'); ?>" class="btn btn-outline">
        <span class="he">תמיכה בפרויקט</span><span class="en">Support the Project</span>
      </a>
    </div>
  </div>
  <div id="countdown-bar">
    <div class="cd-event">
      <div class="ev-title he">טקס הכרזת הנבחרים</div>
      <div class="ev-title en">Inaugural Induction Ceremony</div>
      <div class="ev-sub">פתח תקווה · דצמבר 2027 &nbsp;|&nbsp; Petah Tikva · December 2027</div>
    </div>
    <div class="cd-units">
      <div class="cd-unit"><span class="cd-num" id="cd-d">--</span><div class="cd-lbl he">ימים</div><div class="cd-lbl en">DAYS</div></div>
      <span class="cd-colon">:</span>
      <div class="cd-unit"><span class="cd-num" id="cd-h">--</span><div class="cd-lbl he">שעות</div><div class="cd-lbl en">HRS</div></div>
      <span class="cd-colon">:</span>
      <div class="cd-unit"><span class="cd-num" id="cd-m">--</span><div class="cd-lbl he">דקות</div><div class="cd-lbl en">MIN</div></div>
      <span class="cd-colon">:</span>
      <div class="cd-unit"><span class="cd-num" id="cd-s">--</span><div class="cd-lbl he">שניות</div><div class="cd-lbl en">SEC</div></div>
    </div>
  </div>
</section>

<section id="about">
  <div class="about-grid">
    <div class="about-copy reveal">
      <span class="eyebrow"><span class="he">אודות הפרס</span><span class="en">About the Award</span></span>
      <h2 class="section-title"><span class="he">הצליל של עמנו</span><span class="en">The Sound of Our People</span></h2>
      <div class="rule"></div>
      <p><span class="he">המוזיקה היהודית היא הגשר המחבר בין עבר, הווה ועתיד — שפה ללא גבולות שנדדה עם העם היהודי בכל תפוצותיו.</span><span class="en">Jewish music is the bridge connecting past, present and future — a language without borders that travelled with the Jewish people through every diaspora.</span></p>
      <p><span class="he">חזון טקס פרסי היכל התהילה הוא להעניק הכרה רשמית, ממלכתית ומכובדת ליוצרים ומבצעים שעיצבו את פס הקול היהודי לדורותיו, הן בישראל והן ברחבי העולם.</span><span class="en">The Jewish Music Hall of Fame Awards' vision is to grant official, prestigious state recognition to creators and performers who shaped the Jewish sound for generations — in Israel and worldwide.</span></p>
      <p><span class="he">הטקס הראשון ייערך בדצמבר 2027 בהיכל התרבות פתח תקווה, במסגרת חגיגות 150 שנה לעיר, בנוכחות נשיא המדינה, ראש הממשלה ושר התרבות.</span><span class="en">The inaugural ceremony will take place in December 2027 at the Petah Tikva Cultural Center, as part of the city's 150th anniversary, in the presence of the President, Prime Minister and Minister of Culture.</span></p>
      <br>
      <a href="<?php echo home_url('/support/'); ?>" class="btn btn-gold"><span class="he">הצטרפו אלינו</span><span class="en">Join Us</span></a>
    </div>
    <div class="about-stats reveal reveal-d2">
      <div class="stat"><div class="stat-n">12</div><div class="stat-d he">קטגוריות פרס — מיטב האמנים בכל תחומי המוזיקה היהודית</div><div class="stat-d en">Award categories — the best artists across all Jewish music genres</div></div>
      <div class="stat"><div class="stat-n">3</div><div class="stat-d he">שופטים מקצועיים לכל קטגוריה — החלטה פה אחד בלבד</div><div class="stat-d en">Expert judges per category — unanimous decisions required</div></div>
      <div class="stat"><div class="stat-n">2027</div><div class="stat-d he">שנת הטקס הראשון — שידור חי לישראל ולעולם</div><div class="stat-d en">Year of the first ceremony — live broadcast to Israel and the world</div></div>
      <div class="stat"><div class="stat-n">150</div><div class="stat-d he">שנות פתח תקווה — המסגרת החגיגית לטקס הפתיחה</div><div class="stat-d en">Years of Petah Tikva — the celebratory backdrop for the ceremony</div></div>
    </div>
  </div>
</section>

<section id="categories">
  <div class="cat-header reveal">
    <span class="eyebrow"><span class="he">קטגוריות הפרס</span><span class="en">Award Categories</span></span>
    <h2 class="section-title"><span class="he">12 קטגוריות — מחזור 2027</span><span class="en">12 Categories — Inaugural 2027</span></h2>
    <div class="rule"></div>
  </div>
  <div class="cat-grid">
    <?php
    $cats = [
      ['01','🎤','זמר','Male Singer','בכל השפות והסגנונות','All languages &amp; styles',false],
      ['02','🎤','זמרת','Female Singer','בכל השפות והסגנונות','All languages &amp; styles',false],
      ['03','🕍','חזן / פייטן','Cantor / Paytan','אשכנזי ומזרחי','Ashkenazi &amp; Mizrahi',false],
      ['04','🇮🇱','זמר ישראלי','Israeli Male Singer','זמר עברי, פופ, רוק, ג\'אז','Hebrew song, pop, rock, jazz',false],
      ['05','🇮🇱','זמרת ישראלית','Israeli Female Singer','זמר עברי, פופ, רוק, ג\'אז','Hebrew song, pop, rock, jazz',false],
      ['06','🌊','זמר/ת ים תיכוני','Mediterranean Singer','מישראל ומארצות המזרח','From Israel &amp; Eastern countries',false],
      ['07','🎸','להקה','Band / Ensemble','כל הסגנונות והשפות, כליזמר','All styles &amp; languages, klezmer',false],
      ['08','🎼','מלחין / מעבד / מנצח','Composer / Arranger / Conductor','קלאסי, מחזמר, אופרה','Classical, musical theatre, opera',false],
      ['09','🎹','פסנתרן','Pianist','קלאסי ופופולרי','Classical &amp; popular',false],
      ['10','🎻','נגן כלי מיתר','String Instrumentalist','קלאסי ופופולרי','Classical &amp; popular',false],
      ['11','🎷','נגן כלי נשיפה','Wind Instrumentalist','קלאסי ופופולרי','Classical &amp; popular',false],
      ['12','🥁','נגן כלי הקשה','Percussion Instrumentalist','מישראל ומהתפוצות · פרס הקהל','From Israel &amp; diaspora · voted by the public',true],
    ];
    $delays = ['reveal-d1','reveal-d2','reveal-d3','reveal-d4'];
    foreach ($cats as $i => $c) :
      $delay = $delays[$i % 4];
      $cat_url = home_url('/category/?catid=' . $c[0]);
      $extra_style = $c[6] ? ' style="border-bottom-color:var(--gold);"' : '';
    ?>
    <div class="cat-card reveal <?php echo $delay; ?>"<?php echo $extra_style; ?> onclick="location.href='<?php echo esc_url($cat_url); ?>'">
      <?php if ($c[6]) : ?>
      <div class="badge-pc he">פרס הקהל</div>
      <div class="badge-pc en">People's Choice</div>
      <?php endif; ?>
      <div class="cat-num"><?php echo $c[0]; ?></div>
      <span class="cat-icon"><?php echo $c[1]; ?></span>
      <div class="cat-name he"><?php echo $c[2]; ?></div>
      <div class="cat-name en"><?php echo $c[3]; ?></div>
      <div class="cat-sub he"><?php echo $c[4]; ?></div>
      <div class="cat-sub en"><?php echo $c[5]; ?></div>
      <span class="cat-arrow">→</span>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<section id="ceremony">
  <div class="ceremony-grid">
    <div class="ceremony-img-wrap reveal">
      <img src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=900&q=80" alt="Ceremony hall" loading="lazy"/>
      <div class="ceremony-badge">
        <div class="cb-date">DEC 2027</div>
        <div class="cb-place he">היכל התרבות · פתח תקווה</div>
        <div class="cb-place en">Culture Hall · Petah Tikva</div>
      </div>
    </div>
    <div class="reveal reveal-d2">
      <span class="eyebrow"><span class="he">הטקס</span><span class="en">The Ceremony</span></span>
      <h2 class="section-title"><span class="he">טקס הכרזת הנבחרים</span><span class="en">The Induction Ceremony</span></h2>
      <div class="rule"></div>
      <ul class="ceremony-list">
        <li><span class="ico">📅</span><span><strong><span class="he">דצמבר 2027 — טקס ממלכתי ראשון</span><span class="en">December 2027 — Inaugural State Ceremony</span></strong><span class="he">מחזור פתיחה היסטורי</span><span class="en">A historic first class</span></span></li>
        <li><span class="ico">📍</span><span><strong><span class="he">היכל התרבות, פתח תקווה</span><span class="en">Culture Hall, Petah Tikva</span></strong><span class="he">במסגרת חגיגות 150 שנה לעיר</span><span class="en">As part of the city's 150th anniversary</span></span></li>
        <li><span class="ico">🏛️</span><span><strong><span class="he">בנוכחות ראשי המדינה</span><span class="en">In the presence of state leaders</span></strong><span class="he">נשיא המדינה, ראש הממשלה, שר התרבות</span><span class="en">President, Prime Minister, Minister of Culture</span></span></li>
        <li><span class="ico">📺</span><span><strong><span class="he">שידור חי לישראל ולעולם</span><span class="en">Live broadcast to Israel &amp; worldwide</span></strong><span class="he">שידור ישיר בטלוויזיה ודיגיטלי</span><span class="en">Television &amp; digital livestream</span></span></li>
        <li><span class="ico">🎵</span><span><strong><span class="he">הופעות חיות ומחוות מיוחדות</span><span class="en">Live performances &amp; special tributes</span></strong><span class="he">קטעי ביצוע וסרטוני מחווה לנבחרים</span><span class="en">Musical performances and tribute films for each inductee</span></span></li>
      </ul>
      <br>
      <a href="#newsletter" class="btn btn-gold"><span class="he">קבלו עדכונים</span><span class="en">Get Updates</span></a>
    </div>
  </div>
</section>

<section id="process">
  <div class="process-inner">
    <div class="reveal">
      <span class="eyebrow"><span class="he">תהליך הבחירה</span><span class="en">Selection Process</span></span>
      <h2 class="section-title"><span class="he">יוקרה, שקיפות ואמינות</span><span class="en">Prestige, Transparency &amp; Integrity</span></h2>
      <div class="rule"></div>
    </div>
    <div class="steps">
      <div class="step reveal reveal-d1"><div class="step-dot">א</div><div class="step-body"><h4><span class="he">הנהלת הפרס קובעת את הרכב ועדות השופטים</span><span class="en">Management appoints the judging panels</span></h4><p><span class="he">3 שופטים מקצועיים לכל קטגוריה, בהתייעצות עם מומחים בתחום. שמות השופטים נשמרים חסויים עד לפרסום הרשמי.</span><span class="en">3 professional judges per category, in consultation with domain experts. Judges' identities remain confidential until official announcement.</span></p></div></div>
      <div class="step reveal reveal-d2"><div class="step-dot">ב</div><div class="step-body"><h4><span class="he">סינון מקצועי — ישיבות בין ינואר–מרץ 2027</span><span class="en">Professional shortlisting — January–March 2027</span></h4><p><span class="he">כל שופט רשאי להציע מועמדים בכתב. הדיונים נשמרים בסודיות מוחלטת ואין פרוטוקול גלוי.</span><span class="en">Each judge may propose candidates in writing. Deliberations are held in full confidentiality — no public minutes.</span></p></div></div>
      <div class="step reveal reveal-d3"><div class="step-dot">ג</div><div class="step-body"><h4><span class="he">החלטה פה אחד בלבד</span><span class="en">Unanimous decision required</span></h4><p><span class="he">לכל קטגוריה נבחרים זוכה ראשון ומועמד חלופי. ההחלטה חייבת להתקבל פה אחד — ללא קונסנזוס לא יוענק פרס.</span><span class="en">A winner and alternate are selected per category. The decision must be unanimous — if no consensus is reached, the award is withheld.</span></p></div></div>
      <div class="step reveal reveal-d4"><div class="step-dot">ד</div><div class="step-body"><h4><span class="he">אישור ופרסום — מחצית ב' 2027</span><span class="en">Ratification &amp; announcement — H2 2027</span></h4><p><span class="he">יו"ר מיתר מאשר את ההמלצות, הזוכים מיודעים באופן פרטי ומאשרים נוכחות, ואז מתפרסמת ההודעה הרשמית.</span><span class="en">The Mitar chairperson ratifies recommendations. Winners are notified privately and confirm attendance before the official announcement.</span></p></div></div>
    </div>
  </div>
</section>

<section id="support" class="reveal">
  <span class="eyebrow"><span class="he">תמיכה בפרויקט</span><span class="en">Support the Project</span></span>
  <h2 class="section-title"><span class="he">היו שותפים לכתיבת ההיסטוריה</span><span class="en">Be Part of Making History</span></h2>
  <div class="rule center"></div>
  <p><span class="he">טקס פרסי היכל התהילה של המוזיקה היהודית הוא פרויקט לאומי ובינלאומי. תרומתכם תסייע לבנות מורשת מוזיקלית לדורות.</span><span class="en">The Jewish Music Hall of Fame Awards is a national and international project. Your support helps build a musical legacy for generations.</span></p>
  <div class="support-ctas">
    <a href="<?php echo home_url('/support/'); ?>" class="btn btn-gold"><span class="he">צרו קשר</span><span class="en">Get in Touch</span></a>
    <a href="#process" class="btn btn-outline"><span class="he">קראו על תהליך הבחירה</span><span class="en">Read About Our Process</span></a>
  </div>
</section>

<section id="newsletter" class="reveal">
  <span class="eyebrow"><span class="he">הישארו מעודכנים</span><span class="en">Stay Updated</span></span>
  <h3 class="section-title" style="font-size:1.9rem;"><span class="he">הצטרפו לרשימת הדיוור</span><span class="en">Join Our Mailing List</span></h3>
  <p><span class="he">קבלו עדכונים ראשונים על המועמדים, לוח הזמנים, הטקס ועוד</span><span class="en">Be first to hear about nominees, the timeline, the ceremony and more</span></p>
  <form class="nl-form" onsubmit="handleNewsletter(event)">
    <input type="email" id="nl-email" required data-he="כתובת אימייל שלכם" data-en="Your email address" placeholder="כתובת אימייל שלכם" />
    <button type="submit"><span class="he">הרשמה</span><span class="en">Subscribe</span></button>
  </form>
</section>

<footer>
  <div class="footer-grid">
    <div class="footer-about">
      <div class="fa-logo he">טקס פרסי היכל התהילה של המוזיקה היהודית</div>
      <div class="fa-logo en">Jewish Music Hall of Fame Awards</div>
      <p><span class="he">הכרה ממלכתית ויוקרתית ליוצרים ומבצעים שעיצבו את המוזיקה היהודית לדורותיה.</span><span class="en">Prestigious state recognition for the creators and performers who shaped Jewish music for generations.</span></p>
    </div>
    <div class="footer-col">
      <h5><span class="he">ניווט</span><span class="en">Navigation</span></h5>
      <ul>
        <li><a href="#about"><span class="he">אודות</span><span class="en">About</span></a></li>
        <li><a href="<?php echo home_url('/categories/'); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a></li>
        <li><a href="#ceremony"><span class="he">הטקס</span><span class="en">Ceremony</span></a></li>
        <li><a href="#process"><span class="he">תהליך הבחירה</span><span class="en">Selection</span></a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5><span class="he">פרויקט</span><span class="en">Project</span></h5>
      <ul>
        <li><a href="<?php echo home_url('/categories/'); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a></li>
        <li><a href="<?php echo home_url('/support/'); ?>"><span class="he">תמיכה</span><span class="en">Support Us</span></a></li>
        <li><a href="#newsletter"><span class="he">ניוזלטר</span><span class="en">Newsletter</span></a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5><span class="he">צרו קשר</span><span class="en">Contact</span></h5>
      <ul>
        <li><a href="mailto:info@jewishmusichalloffame.org">info@jewishmusichalloffame.org</a></li>
        <li><a href="#"><span class="he">פתח תקווה, ישראל</span><span class="en">Petah Tikva, Israel</span></a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2026 ✡ <span class="he">טקס פרסי היכל התהילה של המוזיקה היהודית</span><span class="en">Jewish Music Hall of Fame Awards</span></span>
    <span><span class="he">כל הזכויות שמורות</span><span class="en">All rights reserved</span></span>
  </div>
</footer>

<script>
let lang='he';
function switchLang(){
  lang=lang==='he'?'en':'he';
  const html=document.getElementById('html-root'),body=document.body,btn=document.getElementById('lang-btn'),inp=document.getElementById('nl-email');
  if(lang==='en'){body.classList.add('lang-en');html.lang='en';html.dir='ltr';btn.textContent='עברית';localStorage.setItem('lang','en');inp.placeholder=inp.dataset.en;}
  else{body.classList.remove('lang-en');html.lang='he';html.dir='rtl';btn.textContent='ENGLISH';localStorage.setItem('lang','he');inp.placeholder=inp.dataset.he;}
}
const navbar=document.getElementById('navbar');
window.addEventListener('scroll',()=>{navbar.classList.toggle('solid',window.scrollY>50);},{passive:true});
function tick(){
  const diff=new Date('2027-12-28T20:00:00')-Date.now();
  if(diff<=0)return;
  const pad=n=>String(Math.floor(n)).padStart(2,'0');
  document.getElementById('cd-d').textContent=pad(diff/86400000);
  document.getElementById('cd-h').textContent=pad((diff%86400000)/3600000);
  document.getElementById('cd-m').textContent=pad((diff%3600000)/60000);
  document.getElementById('cd-s').textContent=pad((diff%60000)/1000);
}
tick();setInterval(tick,1000);
const savedLang=localStorage.getItem('lang');
if(savedLang==='en'){lang='en';document.body.classList.add('lang-en');document.getElementById('html-root').lang='en';document.getElementById('html-root').dir='ltr';document.getElementById('lang-btn').textContent='עברית';document.querySelectorAll('[data-en]').forEach(el=>{el.placeholder=el.dataset.en;});}
const io=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('on');});},{threshold:0.1});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
const pc=document.getElementById('particles');
for(let i=0;i<30;i++){const p=document.createElement('div');p.className='pt';const s=Math.random()*3+1;p.style.cssText=`left:${Math.random()*100}%;width:${s}px;height:${s}px;animation-duration:${Math.random()*9+6}s;animation-delay:${Math.random()*10}s;`;pc.appendChild(p);}
function handleNewsletter(e){e.preventDefault();const inp=document.getElementById('nl-email');const msg=lang==='he'?`תודה! ${inp.value} נרשם/ה בהצלחה.`:`Thank you! ${inp.value} has been subscribed.`;inp.value='';inp.placeholder=msg;setTimeout(()=>{inp.placeholder=lang==='he'?inp.dataset.he:inp.dataset.en;},4000);}
document.querySelectorAll('a[href^="#"]').forEach(a=>{a.addEventListener('click',e=>{const id=a.getAttribute('href');if(id==='#')return;const el=document.querySelector(id);if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth',block:'start'});}});});
</script>
<?php wp_footer(); ?>
</body>
</html>
