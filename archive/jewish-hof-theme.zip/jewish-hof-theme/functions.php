<?php
defined('ABSPATH') || exit;

/* ── Hide admin bar on front end ── */
add_filter('show_admin_bar', '__return_false');

/* ── Basic theme setup ── */
function hof_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'hof_setup');

/* ── Contact form handler ── */
function hof_handle_contact() {
    if (!isset($_POST['hof_nonce']) || !wp_verify_nonce($_POST['hof_nonce'], 'hof_contact_nonce')) {
        wp_redirect(home_url('/support/?form=error'));
        exit;
    }

    $first   = sanitize_text_field($_POST['first_name'] ?? '');
    $last    = sanitize_text_field($_POST['last_name']  ?? '');
    $email   = sanitize_email($_POST['email']           ?? '');
    $org     = sanitize_text_field($_POST['org']        ?? '');
    $level   = sanitize_text_field($_POST['level']      ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (!is_email($email)) {
        wp_redirect(home_url('/support/?form=error'));
        exit;
    }

    $to      = get_option('admin_email');
    $subject = 'HOF Contact: ' . $first . ' ' . $last . ' — ' . $level;
    $body    = "Name: $first $last\nEmail: $email\nOrg: $org\nLevel: $level\n\nMessage:\n$message";
    $headers = ['Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $email];

    wp_mail($to, $subject, $body, $headers);

    wp_redirect(home_url('/support/?form=success'));
    exit;
}
add_action('admin_post_nopriv_hof_contact', 'hof_handle_contact');
add_action('admin_post_hof_contact',        'hof_handle_contact');
