<?php
defined('ABSPATH') || exit;
/**
 * Template Name: Categories Page
 */
?><!DOCTYPE html>
<html lang="he" dir="rtl" id="html-root">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>קטגוריות הפרס | טקס פרסי היכל התהילה של המוזיקה היהודית</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;0,700;1,400&family=Heebo:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<?php wp_head(); ?>
<style>
:root {
  --gold: #C9A84C;
  --gold-light: #E2C46A;
  --gold-dark: #8A6E28;
  --gold-glow: rgba(201,168,76,0.12);
  --black: #080808;
  --dark1: #101010;
  --dark2: #181818;
  --dark3: #222222;
  --grey2: #252830;
  --blue: #2A4A7F;
  --blue-light: #3D6BAF;
  --white: #F4EFE6;
  --white-70: rgba(244,239,230,0.70);
  --white-40: rgba(244,239,230,0.40);
  --white-12: rgba(244,239,230,0.12);
  --white-06: rgba(244,239,230,0.06);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }

body {
  background: var(--black);
  color: var(--white);
  font-family: 'Heebo', sans-serif;
  direction: rtl;
  overflow-x: hidden;
}
body.lang-en {
  direction: ltr;
  font-family: 'Cormorant Garamond', serif;
  font-size: 106%;
}

a { text-decoration: none; color: inherit; }
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: var(--black); }
::-webkit-scrollbar-thumb { background: var(--gold-dark); }

.he { display: block; } .en { display: none; }
body.lang-en .he { display: none !important; }
body.lang-en .en { display: block !important; }

/* NAVBAR */
#navbar {
  position: fixed; inset: 0 0 auto; z-index: 900;
  display: flex; align-items: center; justify-content: space-between;
  padding: 1.1rem 2.5rem;
  background: rgba(8,8,8,0.97);
  border-bottom: 1px solid rgba(201,168,76,0.18);
  direction: ltr;
}
.nav-brand { display: flex; align-items: center; gap: 0.75rem; }
.nav-star { width: 38px; height: 38px; border: 1.5px solid var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
.nav-brand-text .t1 { font-size: 0.78rem; font-weight: 700; color: var(--gold); }
.nav-brand-text .t2 { font-size: 0.58rem; color: var(--white-40); letter-spacing: 2px; text-transform: uppercase; }
.nav-links { display: flex; gap: 2rem; list-style: none; }
.nav-links a { font-size: 0.72rem; letter-spacing: 1.5px; text-transform: uppercase; color: var(--white-70); transition: color 0.2s; }
.nav-links a:hover, .nav-links a.active { color: var(--gold); }
#lang-btn {
  background: transparent; border: 1px solid var(--gold); color: var(--gold);
  font-size: 0.7rem; letter-spacing: 2px; padding: 0.35rem 1rem;
  cursor: pointer; font-family: inherit; transition: all 0.2s;
}
#lang-btn:hover { background: var(--gold); color: var(--black); }

/* PAGE HERO */
.page-hero {
  padding: 9rem 2rem 5rem;
  text-align: center;
  background:
    radial-gradient(ellipse 80% 60% at 50% 70%, rgba(42,74,127,0.2), transparent 70%),
    radial-gradient(ellipse 80% 50% at 50% 60%, rgba(201,168,76,0.07), transparent 70%),
    linear-gradient(175deg, var(--dark1), var(--black));
  border-bottom: 1px solid rgba(201,168,76,0.15);
  position: relative;
}
.page-hero::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: linear-gradient(90deg, transparent, var(--gold), transparent);
}
.eyebrow {
  display: block; font-size: 0.65rem; letter-spacing: 5px; text-transform: uppercase;
  color: var(--gold); margin-bottom: 0.9rem;
  animation: labelGlow 3s ease-in-out infinite;
  text-shadow: 0 0 12px rgba(201,168,76,0.3);
}
.page-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: clamp(2.2rem, 5vw, 4rem);
  font-weight: 700; line-height: 1.1; margin-bottom: 1rem;
  text-shadow: 0 2px 20px rgba(42,74,127,0.15);
}
body:not(.lang-en) .page-title { font-family: 'Heebo', sans-serif; font-weight: 900; }
.rule {
  width: 48px; height: 2px; margin: 1.2rem auto 0;
  background: linear-gradient(90deg, transparent, var(--gold), var(--blue-light), var(--gold), transparent);
  background-size: 200% auto;
  animation: shimmer 3s linear infinite;
}
.page-intro { max-width: 620px; margin: 1.8rem auto 0; color: var(--white-70); font-size: 1rem; line-height: 1.8; }

/* FILTER TABS */
.filter-bar {
  display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap;
  padding: 2.5rem 2rem 0;
  max-width: 1200px; margin: 0 auto;
}
.filter-btn {
  background: var(--dark2); border: 1px solid var(--white-12);
  color: var(--white-40); font-size: 0.7rem; letter-spacing: 2px;
  text-transform: uppercase; padding: 0.5rem 1.2rem;
  cursor: pointer; font-family: inherit; transition: all 0.2s;
}
.filter-btn:hover, .filter-btn.active { background: var(--gold); color: var(--black); border-color: var(--gold); font-weight: 700; }

/* CATEGORIES GRID */
.categories-wrap {
  max-width: 1200px; margin: 0 auto;
  padding: 3rem 2rem 6rem;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
  gap: 2px;
}

/* CATEGORY CARD */
.cat-card {
  background: linear-gradient(135deg, var(--dark2), var(--grey2));
  padding: 0;
  position: relative;
  overflow: hidden;
  display: flex; flex-direction: column;
  border-bottom: 2px solid transparent;
  transition: border-color 0.3s, transform 0.3s, box-shadow 0.3s;
}
.cat-card:hover {
  border-bottom-color: var(--gold);
  transform: translateY(-4px);
  box-shadow: 0 8px 32px rgba(42,74,127,0.25), 0 2px 8px rgba(201,168,76,0.1);
}

.cat-card-top {
  padding: 2.2rem 2rem 1.5rem;
  position: relative;
}
.cat-card-top::before {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(135deg, var(--gold-glow), transparent 70%);
  opacity: 0; transition: opacity 0.3s;
}
.cat-card:hover .cat-card-top::before { opacity: 1; }

.cat-header { display: flex; align-items: flex-start; gap: 1rem; margin-bottom: 1.2rem; }
.cat-icon-wrap {
  width: 56px; height: 56px; flex-shrink: 0;
  background: linear-gradient(135deg, var(--grey2), var(--dark3));
  border: 1px solid rgba(42,74,127,0.35);
  display: flex; align-items: center; justify-content: center;
  font-size: 1.6rem;
  transition: background 0.3s, box-shadow 0.3s;
}
.cat-card:hover .cat-icon-wrap {
  box-shadow: 0 0 16px rgba(42,74,127,0.4);
  border-color: var(--gold);
}
.cat-meta { flex: 1; }
.cat-num { font-size: 0.58rem; letter-spacing: 3px; color: var(--gold); margin-bottom: 0.3rem; }
.cat-name { font-size: 1.15rem; font-weight: 700; line-height: 1.25; margin-bottom: 0.2rem; }
body.lang-en .cat-name { font-family: 'Cormorant Garamond', serif; font-size: 1.25rem; font-weight: 600; }
.cat-name-sub { font-size: 0.78rem; color: var(--white-40); }

.cat-desc { font-size: 0.875rem; color: var(--white-70); line-height: 1.75; margin-bottom: 1.2rem; }

.cat-tags { display: flex; flex-wrap: wrap; gap: 0.4rem; }
.cat-tag {
  background: var(--dark3); border: 1px solid var(--white-12);
  color: var(--white-40); font-size: 0.62rem;
  letter-spacing: 1px; text-transform: uppercase;
  padding: 0.25rem 0.65rem;
}

.cat-card-footer {
  padding: 1rem 2rem;
  border-top: 1px solid var(--white-06);
  display: flex; align-items: center; justify-content: space-between;
  margin-top: auto;
}
.peoples-badge {
  background: var(--gold); color: var(--black);
  font-size: 0.58rem; font-weight: 700; letter-spacing: 1.5px;
  text-transform: uppercase; padding: 0.22rem 0.7rem;
}
.world-badge {
  background: transparent; color: var(--gold);
  border: 1px solid var(--gold);
  font-size: 0.58rem; letter-spacing: 1.5px;
  text-transform: uppercase; padding: 0.22rem 0.7rem;
}
.cat-link {
  font-size: 0.68rem; letter-spacing: 2px; text-transform: uppercase;
  color: var(--gold-dark); transition: color 0.2s;
  display: flex; align-items: center; gap: 0.4rem;
}
.cat-card:hover .cat-link { color: var(--gold); }

/* FOOTER */
footer {
  background: linear-gradient(180deg, var(--dark1), var(--black));
  border-top: 1px solid var(--white-06);
  padding: 2.5rem 2rem;
  text-align: center;
}
.footer-links { display: flex; gap: 2rem; justify-content: center; flex-wrap: wrap; margin-bottom: 1.2rem; }
.footer-links a { font-size: 0.75rem; color: var(--white-40); letter-spacing: 1px; transition: color 0.2s; }
.footer-links a:hover { color: var(--gold); }
.footer-copy { font-size: 0.7rem; color: var(--white-40); }

/* REVEAL */
.reveal { opacity: 0; transform: translateY(28px); transition: opacity 0.7s, transform 0.7s; }
.reveal.on { opacity: 1; transform: none; }
.reveal-d1 { transition-delay: 0.08s; }
.reveal-d2 { transition-delay: 0.16s; }
.reveal-d3 { transition-delay: 0.24s; }

@keyframes shimmer { 0% { background-position:-200% center; } 100% { background-position:200% center; } }
@keyframes labelGlow { 0%, 100% { opacity: 0.85; letter-spacing: 5px; } 50% { opacity: 1; letter-spacing: 5.5px; } }

@media (max-width: 900px) {
  .nav-links { display: none; }
  .categories-wrap { grid-template-columns: 1fr; }
}
@media (max-width: 600px) {
  .categories-wrap { grid-template-columns: 1fr; padding: 2rem 1rem 4rem; }
  #navbar { padding: 1rem 1.2rem; }
}
</style>
</head>
<body <?php body_class(); ?>>

<!-- NAVBAR -->
<nav id="navbar">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-brand">
    <div class="nav-star">✡</div>
    <div class="nav-brand-text">
      <div class="t1 he">טקס פרסי היכל התהילה</div>
      <div class="t1 en">Hall of Fame Awards</div>
      <div class="t2">Jewish Music · 2027</div>
    </div>
  </a>
  <ul class="nav-links">
    <li><a href="<?php echo esc_url(home_url('/')); ?>"><span class="he">בית</span><span class="en">Home</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/categories/')); ?>" class="active"><span class="he">קטגוריות</span><span class="en">Categories</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/support/')); ?>"><span class="he">תורמים</span><span class="en">Support Us</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/#ceremony')); ?>"><span class="he">הטקס</span><span class="en">Ceremony</span></a></li>
    <li><a href="<?php echo esc_url(home_url('/#process')); ?>"><span class="he">תהליך הבחירה</span><span class="en">Selection</span></a></li>
  </ul>
  <button id="lang-btn" onclick="switchLang()">ENGLISH</button>
</nav>

<!-- PAGE HERO -->
<div class="page-hero">
  <span class="eyebrow"><span class="he">מחזור 2027</span><span class="en">Inaugural Class 2027</span></span>
  <h1 class="page-title">
    <span class="he">קטגוריות הפרס</span>
    <span class="en">Award Categories</span>
  </h1>
  <div class="rule"></div>
  <p class="page-intro">
    <span class="he">12 קטגוריות המכסות את כל עולמות המוזיקה היהודית — מהחזנות המסורתית ועד הפופ הישראלי, מהקלאסי ועד הים-תיכוני. בכל קטגוריה יחליט ועד שופטים בן שלושה מומחים, פה אחד בלבד.</span>
    <span class="en">12 categories spanning the entire world of Jewish music — from traditional cantorial to Israeli pop, classical to Mediterranean. In each category, a panel of three expert judges decides unanimously.</span>
  </p>
</div>

<!-- FILTER BAR -->
<div class="filter-bar reveal">
  <button class="filter-btn active" onclick="filterCats('all', this)">
    <span class="he">הכל</span><span class="en">All</span>
  </button>
  <button class="filter-btn" onclick="filterCats('vocal', this)">
    <span class="he">קולי</span><span class="en">Vocal</span>
  </button>
  <button class="filter-btn" onclick="filterCats('instrumental', this)">
    <span class="he">כלי נגינה</span><span class="en">Instrumental</span>
  </button>
  <button class="filter-btn" onclick="filterCats('group', this)">
    <span class="he">הרכב</span><span class="en">Group</span>
  </button>
  <button class="filter-btn" onclick="filterCats('classical', this)">
    <span class="he">קלאסי</span><span class="en">Classical</span>
  </button>
</div>

<!-- CATEGORIES GRID -->
<div class="categories-wrap">
<?php
$cats = [
  ['01','🎤','זמר','Male Singer','בכל השפות והסגנונות','All languages &amp; styles','vocal',false,
   'זמר יהודי שהותיר חותם בלתי נמחה על המוזיקה היהודית — בכל שפה ובכל סגנון. מיידיש וספרדית ועד ערבית ועברית, ממוזיקה דתית ועד מוזיקת עולם.',
   'A Jewish male vocalist who has left an indelible mark on Jewish music — in any language and any style. From Yiddish and Ladino to Arabic and Hebrew, from sacred music to world music.',
   ['Yiddish','Ladino','Hebrew','Arabic','<span class="cat-tag he">כל הסגנונות</span><span class="cat-tag en">All styles</span>']],
  ['02','🎤','זמרת','Female Singer','בכל השפות והסגנונות','All languages &amp; styles','vocal',false,
   'זמרת יהודייה שקולה ואמנותה עיצבו את הזהות המוזיקלית היהודית לדורות. הקטגוריה פתוחה לכל שפה, תקופה וסגנון.',
   'A Jewish female vocalist whose voice and artistry have shaped Jewish musical identity for generations. Open to any language, era, and style.',
   ['Yiddish','Ladino','Hebrew','<span class="cat-tag he">כל הסגנונות</span><span class="cat-tag en">All styles</span>']],
  ['03','🕍','חזן / פייטן','Cantor / Paytan','אשכנזי ומזרחי','Ashkenazi &amp; Mizrahi','vocal',false,
   'חזן או פייטן שיצירתו מגשרת בין הקודש לאמנות — בין אם בנוסח האשכנזי, הספרדי, התימני או המזרחי. שומר מסורת ומחדש בה כאחד.',
   'A cantor or paytan whose work bridges the sacred and the artistic — whether in Ashkenazi, Sephardic, Yemenite or Mizrahi tradition.',
   ['<span class="cat-tag he">אשכנזי</span><span class="cat-tag en">Ashkenazi</span>','<span class="cat-tag he">מזרחי</span><span class="cat-tag en">Mizrahi</span>','<span class="cat-tag he">ספרדי</span><span class="cat-tag en">Sephardic</span>','<span class="cat-tag he">תימני</span><span class="cat-tag en">Yemenite</span>']],
  ['04','🇮🇱','זמר ישראלי','Israeli Male Singer',"זמר עברי, פופ, רוק, ג'אז",'Hebrew song, pop, rock, jazz','vocal',false,
   "זמר ישראלי שתרם תרומה יוצאת דופן לזמר העברי ולתרבות הישראלית. מאבות הזמר הישראלי ועד לאמנים המעצבים את הסצנה הנוכחית.",
   'An Israeli male singer who made an outstanding contribution to Hebrew song and Israeli culture — from the founding fathers to artists shaping the contemporary scene.',
   ['<span class="cat-tag he">זמר עברי</span><span class="cat-tag en">Hebrew song</span>','Pop','Rock','Jazz']],
  ['05','🇮🇱','זמרת ישראלית','Israeli Female Singer',"זמר עברי, פופ, רוק, ג'אז",'Hebrew song, pop, rock, jazz','vocal',false,
   "זמרת ישראלית שקולה הפך לסמל תרבותי — בזמר עברי, פופ, רוק או ג'אז. אמנית שנוכחותה ויצירתה ייצגו את ישראל בארץ ובעולם.",
   'An Israeli female singer whose voice became a cultural symbol — in Hebrew song, pop, rock or jazz. An artist whose presence and work represented Israel at home and worldwide.',
   ['<span class="cat-tag he">זמר עברי</span><span class="cat-tag en">Hebrew song</span>','Pop','Rock','Jazz']],
  ['06','🌊','זמר/ת ים-תיכוני','Mediterranean Singer','מישראל ומארצות המזרח','From Israel &amp; Eastern countries','vocal',false,
   'אמן/ית שמוזיקתם שואבת ממסורות ים-תיכוניות ומזרחיות — ממרוקו, תוניסיה, לוב, מצרים, תורכיה, פרס וכן ישראל.',
   'An artist whose music draws from Mediterranean and Eastern traditions — from Morocco, Tunisia, Libya, Egypt, Turkey, Persia and Israel.',
   ['<span class="cat-tag he">מרוקאי</span><span class="cat-tag en">Moroccan</span>','<span class="cat-tag he">פרסי</span><span class="cat-tag en">Persian</span>','<span class="cat-tag he">תורכי</span><span class="cat-tag en">Turkish</span>','<span class="cat-tag he">ים-תיכוני</span><span class="cat-tag en">Mediterranean</span>']],
  ['07','🎸',"להקה / הרכב",'Band / Ensemble',"כל הסגנונות והשפות, כליזמר",'All styles &amp; languages, klezmer','group',false,
   "להקה או הרכב יהודי — ממצמד ומעלה — שיצירתם המשותפת העשירה את עולם המוזיקה היהודית. כולל להקות פופ/רוק ישראליות, הרכבי כליזמר, ג'אז ומוזיקה עולמית.",
   "A Jewish band or ensemble whose collaborative work has enriched the world of Jewish music. Including Israeli pop/rock bands, klezmer ensembles, jazz, and world music groups.",
   ['Klezmer','Pop / Rock','Jazz','<span class="cat-tag he">מוזיקת עולם</span><span class="cat-tag en">World music</span>']],
  ['08','🎼',"מלחין / מעבד / מנצח",'Composer / Arranger / Conductor','קלאסי, מחזמר, אופרה','Classical, musical theatre, opera','group',false,
   "יוצר שמאחורי הקלעים — מלחין, מעבד או מנצח — שיצירותיו ופרשנויותיו הפכו לאבני יסוד של הרפרטואר המוזיקלי היהודי.",
   'A behind-the-scenes creator — composer, arranger or conductor — whose works became cornerstones of the Jewish musical repertoire.',
   ['<span class="cat-tag he">קלאסי</span><span class="cat-tag en">Classical</span>','<span class="cat-tag he">מחזמר</span><span class="cat-tag en">Musical theatre</span>','<span class="cat-tag he">אופרה</span><span class="cat-tag en">Opera</span>','Pop / Rock']],
  ['09','🎹','פסנתרן','Pianist','קלאסי ופופולרי','Classical &amp; popular','instrumental classical','trustees',
   "פסנתרן/ית יהודי/ה שהשאיר/ה חותם בינלאומי על עולם הפסנתר — בתחום הקלאסי, הג'אז, הפופ או הפופולרי. אחד הפרסים יוענק כפרס חבר הנאמנים העולמי.",
   "A Jewish pianist who has left an international mark on the world of piano — classical, jazz, pop or popular. One of the instrumental awards may be designated the World Trustees Award.",
   ['<span class="cat-tag he">קלאסי</span><span class="cat-tag en">Classical</span>','Jazz','<span class="cat-tag he">פופולרי</span><span class="cat-tag en">Popular</span>']],
  ['10','🎻','נגן כלי מיתר','String Instrumentalist','קלאסי ופופולרי','Classical &amp; popular','instrumental classical',false,
   "נגן/ת כלי מיתר — כינור, ויולה, צ'לו, גיטרה, עוד וכדומה — שיצירותיו ופרשנויותיו חצו גבולות ועיצבו את פני המוזיקה היהודית.",
   'A string instrument player — violin, viola, cello, guitar, oud and more — whose works and interpretations crossed borders and shaped the face of Jewish music.',
   ['<span class="cat-tag he">כינור</span><span class="cat-tag en">Violin</span>',"<span class='cat-tag he'>צ'לו</span><span class='cat-tag en'>Cello</span>",'<span class="cat-tag he">גיטרה</span><span class="cat-tag en">Guitar</span>','<span class="cat-tag he">עוד</span><span class="cat-tag en">Oud</span>']],
  ['11','🎷','נגן כלי נשיפה','Wind Instrumentalist','קלאסי ופופולרי','Classical &amp; popular','instrumental',false,
   "נגן/ת כלי נשיפה — קלרינט, סקסופון, חליל, חצוצרה וכדומה — שמוזיקתם הגדירה את הצליל היהודי. שייך לתחום הקלאסי, הכליזמר, הג'אז או הפופולרי.",
   "A wind instrument player — clarinet, saxophone, flute, trumpet and more — whose music defined the Jewish sound, whether in classical, klezmer, jazz or popular genres.",
   ['<span class="cat-tag he">קלרינט</span><span class="cat-tag en">Clarinet</span>','<span class="cat-tag he">סקסופון</span><span class="cat-tag en">Saxophone</span>','Klezmer','Jazz']],
  ['12','🥁','נגן כלי הקשה','Percussion Instrumentalist','מישראל ומהתפוצות · פרס הקהל',"From Israel &amp; diaspora · People's Choice",'instrumental','peoples',
   'נגן/ת כלי הקשה שמוזיקתם מגיעה מישראל ומהתפוצות — תופים, דרבוקה, מרקסים ועוד. הקטגוריה הזאת נבחרת על ידי הקהל הרחב — הצביעו!',
   'A percussion player from Israel or the diaspora — drums, darbuka, maracas and more. This category is chosen by the public — cast your vote!',
   ['<span class="cat-tag he">דרבוקה</span><span class="cat-tag en">Darbuka</span>','<span class="cat-tag he">תופים</span><span class="cat-tag en">Drums</span>','<span class="cat-tag he">ישראל והתפוצות</span><span class="cat-tag en">Israel &amp; diaspora</span>']],
];
$delay_classes = ['reveal-d1','reveal-d2','reveal-d3'];
foreach ($cats as $i => $c) :
  $cat_url = home_url('/category/?catid=' . $c[0]);
  $dc = $delay_classes[$i % 3];
  $is_peoples = ($c[7] === 'peoples');
  $is_trustees = ($c[7] === 'trustees');
  $border_style = $is_peoples ? ' style="border-bottom-color: var(--gold);"' : '';
?>
  <div class="cat-card reveal <?php echo esc_attr($dc); ?>" data-type="<?php echo esc_attr($c[6]); ?>"
       onclick="location.href='<?php echo esc_url($cat_url); ?>'" style="cursor:pointer<?php echo $is_peoples ? ';border-bottom-color:var(--gold)' : ''; ?>">
    <div class="cat-card-top">
      <div class="cat-header">
        <div class="cat-icon-wrap"><?php echo $c[1]; ?></div>
        <div class="cat-meta">
          <div class="cat-num">קטגוריה <?php echo $c[0]; ?> · CATEGORY <?php echo $c[0]; ?></div>
          <div class="cat-name he"><?php echo $c[2]; ?></div>
          <div class="cat-name en"><?php echo $c[3]; ?></div>
          <div class="cat-name-sub he"><?php echo $c[4]; ?></div>
          <div class="cat-name-sub en"><?php echo $c[5]; ?></div>
        </div>
      </div>
      <p class="cat-desc">
        <span class="he"><?php echo $c[8]; ?></span>
        <span class="en"><?php echo $c[9]; ?></span>
      </p>
      <div class="cat-tags">
        <?php foreach ($c[10] as $tag) : ?>
          <?php if (strpos($tag, '<span') === 0) : ?>
            <?php echo $tag; ?>
          <?php else : ?>
            <span class="cat-tag"><?php echo esc_html($tag); ?></span>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="cat-card-footer">
      <?php if ($is_peoples) : ?>
        <span class="peoples-badge he">פרס הקהל — הצביעו</span>
        <span class="peoples-badge en">People's Choice — Vote</span>
      <?php elseif ($is_trustees) : ?>
        <span class="world-badge he">פרס חבר הנאמנים</span>
        <span class="world-badge en">World Trustees Award</span>
      <?php else : ?>
        <span></span>
      <?php endif; ?>
      <?php if ($is_peoples) : ?>
        <span class="cat-link"><span class="he">להצבעה ←</span><span class="en">Vote now →</span></span>
      <?php else : ?>
        <span class="cat-link"><span class="he">פרטים נוספים</span><span class="en">Learn more</span> →</span>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>

</div><!-- end grid -->

<!-- FOOTER -->
<footer>
  <div class="footer-links">
    <a href="<?php echo esc_url(home_url('/')); ?>"><span class="he">דף הבית</span><span class="en">Home</span></a>
    <a href="<?php echo esc_url(home_url('/categories/')); ?>"><span class="he">קטגוריות</span><span class="en">Categories</span></a>
    <a href="<?php echo esc_url(home_url('/support/')); ?>"><span class="he">תמיכה</span><span class="en">Support Us</span></a>
    <a href="<?php echo esc_url(home_url('/#process')); ?>"><span class="he">תהליך הבחירה</span><span class="en">Selection</span></a>
    <a href="<?php echo esc_url(home_url('/#newsletter')); ?>"><span class="he">ניוזלטר</span><span class="en">Newsletter</span></a>
  </div>
  <div class="footer-copy">
    © 2026 ✡ <span class="he">טקס פרסי היכל התהילה של המוזיקה היהודית</span><span class="en">Jewish Music Hall of Fame Awards</span>
  </div>
</footer>

<script>
let lang = 'he';
function switchLang() {
  lang = lang === 'he' ? 'en' : 'he';
  const body = document.body;
  const html = document.getElementById('html-root');
  const btn  = document.getElementById('lang-btn');
  if (lang === 'en') {
    body.classList.add('lang-en'); html.lang = 'en'; html.dir = 'ltr';
    btn.textContent = 'עברית';
    localStorage.setItem('lang', 'en');
  } else {
    body.classList.remove('lang-en'); html.lang = 'he'; html.dir = 'rtl';
    btn.textContent = 'ENGLISH';
    localStorage.setItem('lang', 'he');
  }
}

function filterCats(type, btn) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.cat-card').forEach(card => {
    if (type === 'all' || card.dataset.type.includes(type)) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

const savedLang = localStorage.getItem('lang');
if (savedLang === 'en') {
  lang = 'en';
  document.body.classList.add('lang-en');
  document.getElementById('html-root').lang = 'en';
  document.getElementById('html-root').dir = 'ltr';
  document.getElementById('lang-btn').textContent = 'עברית';
}

const io = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('on'); });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));
</script>
<?php wp_footer(); ?>
</body>
</html>
