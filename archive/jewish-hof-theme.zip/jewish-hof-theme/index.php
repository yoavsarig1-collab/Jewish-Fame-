<?php
/* Fallback — redirect to homepage */
wp_redirect(home_url('/'));
exit;
